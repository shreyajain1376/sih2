import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Globe, Volume2 } from "lucide-react";

const languages = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'हिंदी' },
  { code: 'ta', name: 'தமிழ்' },
  { code: 'te', name: 'తెలుగు' },
  { code: 'ml', name: 'മലയാളം' },
  { code: 'kn', name: 'ಕನ್ನಡ' },
  { code: 'mr', name: 'मराठी' },
  { code: 'bn', name: 'বাংলা' },
  { code: 'gu', name: 'ગુજરાતી' },
  { code: 'pa', name: 'ਪੰਜਾਬੀ' }
];

interface LanguageSelectorProps {
  className?: string;
}

const LanguageSelector = ({ className }: LanguageSelectorProps) => {
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [isOpen, setIsOpen] = useState(false);

  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    // Store language preference
    localStorage.setItem('healthplus_language', language);
    setIsOpen(false);
    
    // In a real app, this would trigger translation updates
    window.dispatchEvent(new CustomEvent('languageChanged', { detail: language }));
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="text-primary-foreground hover:bg-primary-foreground/20 font-bold"
      >
        <Globe className="w-4 h-4 mr-2" />
        Language
      </Button>
      
      {isOpen && (
        <div className="absolute top-full right-0 mt-2 bg-card border border-border rounded-md shadow-lg z-50 min-w-[150px]">
          <div className="p-2 space-y-1">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => handleLanguageChange(lang.code)}
                className={`w-full text-left px-3 py-2 text-sm rounded-md hover:bg-accent transition-colors ${
                  selectedLanguage === lang.code ? 'bg-primary text-primary-foreground' : ''
                }`}
              >
                {lang.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;