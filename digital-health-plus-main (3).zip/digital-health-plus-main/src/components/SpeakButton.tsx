import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Volume2, VolumeX } from "lucide-react";

interface SpeakButtonProps {
  text: string;
  size?: "sm" | "default" | "lg";
  className?: string;
}

const SpeakButton = ({ text, size = "sm", className }: SpeakButtonProps) => {
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleSpeak = () => {
    if (isSpeaking) {
      // Stop speaking
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    // Get selected language
    const selectedLanguage = localStorage.getItem('healthplus_language') || 'en';
    
    // Create speech synthesis utterance
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set language based on selection
    const languageMap: { [key: string]: string } = {
      'en': 'en-US',
      'hi': 'hi-IN',
      'ta': 'ta-IN',
      'te': 'te-IN',
      'ml': 'ml-IN',
      'kn': 'kn-IN',
      'mr': 'mr-IN',
      'bn': 'bn-IN',
      'gu': 'gu-IN',
      'pa': 'pa-IN'
    };
    
    utterance.lang = languageMap[selectedLanguage] || 'en-US';
    utterance.rate = 0.8;
    utterance.pitch = 1;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  return (
    <Button
      variant="ghost"
      size={size}
      onClick={handleSpeak}
      className={`p-1 h-auto hover:bg-accent ${className}`}
    >
      {isSpeaking ? (
        <VolumeX className="w-3 h-3 text-muted-foreground" />
      ) : (
        <Volume2 className="w-3 h-3 text-muted-foreground" />
      )}
    </Button>
  );
};

export default SpeakButton;