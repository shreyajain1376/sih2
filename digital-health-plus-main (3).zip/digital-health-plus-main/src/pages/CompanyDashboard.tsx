import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building, Search, User, BarChart3, LogOut, Trash2, Users, TrendingDown, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import SpeakButton from "@/components/SpeakButton";

const CompanyDashboard = () => {
  const [searchEmployeeId, setSearchEmployeeId] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Sample company data
  const companyData = {
    companyName: "Kerala Construction Corp",
    companyId: "APS3Y10",
    totalEmployees: 1247,
    registeredEmployees: 1089,
    unregisteredEmployees: 158,
    employeesWithDiseases: 234,
    curedEmployees: 567,
    chronicDiseases: 89,
    totalResignedEmployees: 45,
    resignedWithDiseases: 12,
    stateWiseEmployees: [
      { state: "Tamil Nadu", count: 456 },
      { state: "Karnataka", count: 298 },
      { state: "Andhra Pradesh", count: 234 },
      { state: "West Bengal", count: 156 },
      { state: "Others", count: 103 }
    ],
    diseaseBreakdown: [
      { disease: "Hypertension", count: 89 },
      { disease: "Diabetes", count: 67 },
      { disease: "Respiratory Issues", count: 45 },
      { disease: "Back Problems", count: 33 }
    ],
    workingEmployees: [
      { id: "EMP001", name: "Rajesh Kumar", department: "Construction", position: "Site Engineer", joinDate: "2022-03-15", state: "Tamil Nadu", hasDisease: false, disease: "None" },
      { id: "EMP002", name: "Priya Menon", department: "Administration", position: "HR Manager", joinDate: "2021-07-20", state: "Kerala", hasDisease: true, disease: "Diabetes" },
      { id: "EMP003", name: "Mohammed Ali", department: "Construction", position: "Supervisor", joinDate: "2023-01-10", state: "Karnataka", hasDisease: false, disease: "None" },
      { id: "EMP004", name: "Sunita Sharma", department: "Finance", position: "Accountant", joinDate: "2022-11-05", state: "West Bengal", hasDisease: true, disease: "Hypertension" },
      { id: "EMP005", name: "Arjun Nair", department: "Construction", position: "Mason", joinDate: "2023-06-12", state: "Tamil Nadu", hasDisease: false, disease: "None" },
      { id: "EMP006", name: "Lakshmi Pillai", department: "Quality Control", position: "Inspector", joinDate: "2022-09-18", state: "Kerala", hasDisease: true, disease: "Respiratory Issues" },
      { id: "EMP007", name: "Vikram Singh", department: "Construction", position: "Crane Operator", joinDate: "2021-12-03", state: "Andhra Pradesh", hasDisease: false, disease: "None" },
      { id: "EMP008", name: "Deepa Rajesh", department: "Administration", position: "Office Assistant", joinDate: "2023-02-28", state: "Karnataka", hasDisease: true, disease: "Back Problems" },
      { id: "EMP009", name: "Ravi Chandran", department: "Construction", position: "Electrician", joinDate: "2022-08-14", state: "Tamil Nadu", hasDisease: false, disease: "None" },
      { id: "EMP010", name: "Anjali Das", department: "Safety", position: "Safety Officer", joinDate: "2023-04-07", state: "West Bengal", hasDisease: true, disease: "Eye Strain" },
      { id: "EMP011", name: "Suresh Babu", department: "Construction", position: "Plumber", joinDate: "2022-05-22", state: "Andhra Pradesh", hasDisease: false, disease: "None" },
      { id: "EMP012", name: "Kavitha Nair", department: "Procurement", position: "Purchase Manager", joinDate: "2021-10-11", state: "Kerala", hasDisease: true, disease: "Arthritis" },
      { id: "EMP013", name: "Manoj Kumar", department: "Construction", position: "Welder", joinDate: "2023-08-16", state: "Karnataka", hasDisease: false, disease: "None" },
      { id: "EMP014", name: "Shanti Devi", department: "Canteen", position: "Cook", joinDate: "2022-01-30", state: "Tamil Nadu", hasDisease: true, disease: "Joint Pain" },
      { id: "EMP015", name: "Anil Varma", department: "Security", position: "Security Guard", joinDate: "2023-03-25", state: "Andhra Pradesh", hasDisease: false, disease: "None" }
    ],
    resignedEmployees: [
      { id: "JOEY321", name: "Joey Matthews", resignDate: "2024-01-15", hasDisease: true, disease: "Chronic Back Pain" },
      { id: "SMITH456", name: "Smith Kumar", resignDate: "2024-02-20", hasDisease: false, disease: "None" },
      { id: "ANNA789", name: "Anna Joseph", resignDate: "2024-03-10", hasDisease: true, disease: "Diabetes" },
      { id: "MIKE234", name: "Mike Johnson", resignDate: "2024-01-25", hasDisease: true, disease: "Hypertension" },
      { id: "SARA567", name: "Sara Williams", resignDate: "2024-02-14", hasDisease: false, disease: "None" },
      { id: "RAVI890", name: "Ravi Patel", resignDate: "2024-03-05", hasDisease: true, disease: "Respiratory Issues" },
      { id: "PRIYA123", name: "Priya Sharma", resignDate: "2024-01-30", hasDisease: false, disease: "None" },
      { id: "DAVID456", name: "David Brown", resignDate: "2024-02-28", hasDisease: true, disease: "Arthritis" },
      { id: "LISA789", name: "Lisa Wilson", resignDate: "2024-03-12", hasDisease: false, disease: "None" },
      { id: "KUMAR012", name: "Kumar Reddy", resignDate: "2024-02-05", hasDisease: true, disease: "Heart Disease" },
      { id: "MEERA345", name: "Meera Nair", resignDate: "2024-01-18", hasDisease: false, disease: "None" },
      { id: "ALEX678", name: "Alex Taylor", resignDate: "2024-03-08", hasDisease: true, disease: "Chronic Fatigue" },
      { id: "NINA901", name: "Nina Singh", resignDate: "2024-02-11", hasDisease: false, disease: "None" }
    ]
  };

  const searchEmployee = () => {
    if (!searchEmployeeId) {
      toast({
        title: "Employee ID Required",
        description: "Please enter an employee ID to search",
        variant: "destructive"
      });
      return;
    }

    // Search in working employees first
    const workingEmployee = companyData.workingEmployees.find(emp => 
      emp.id.toLowerCase() === searchEmployeeId.toLowerCase()
    );

    if (workingEmployee) {
      const employeeDetails = {
        ...workingEmployee,
        age: 28 + Math.floor(Math.random() * 20), // Random age between 28-48
        mobile: "98765" + Math.floor(10000 + Math.random() * 90000),
        email: `${workingEmployee.name.toLowerCase().replace(' ', '.')}@company.com`,
        bloodGroup: ['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-'][Math.floor(Math.random() * 8)],
        lastCheckup: "2024-01-20",
        status: "Active"
      };
      
      setSelectedEmployee(employeeDetails);
      toast({
        title: "Employee Found",
        description: `${workingEmployee.name} details loaded successfully`
      });
      return;
    }

    // Search in resigned employees
    const resignedEmployee = companyData.resignedEmployees.find(emp => 
      emp.id.toLowerCase() === searchEmployeeId.toLowerCase()
    );

    if (resignedEmployee) {
      const employeeDetails = {
        ...resignedEmployee,
        age: 30 + Math.floor(Math.random() * 15),
        mobile: "98765" + Math.floor(10000 + Math.random() * 90000),
        email: `${resignedEmployee.name.toLowerCase().replace(' ', '.')}@company.com`,
        bloodGroup: ['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-'][Math.floor(Math.random() * 8)],
        lastCheckup: "2024-01-15",
        status: "Resigned",
        department: "Former Employee",
        position: "N/A",
        state: "Unknown"
      };
      
      setSelectedEmployee(employeeDetails);
      toast({
        title: "Former Employee Found",
        description: `${resignedEmployee.name} (resigned) details loaded`
      });
      return;
    }

    // Employee not found
    toast({
      title: "Employee Not Found",
      description: "No employee found with the given ID",
      variant: "destructive"
    });
    setSelectedEmployee(null);
  };

  const deleteEmployee = (employeeId: string) => {
    toast({
      title: "Employee Deleted",
      description: `Employee ${employeeId} has been removed from company database`
    });
  };

  const handleLogout = () => {
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out"
    });
    navigate('/login');
  };

  // Show thank you screen on first load
  const [showThankYou, setShowThankYou] = useState(() => {
    const hasShownThankYou = localStorage.getItem(`company_thankyou_${companyData.companyId}`);
    return !hasShownThankYou;
  });

  if (showThankYou) {
    return (
      <div className="min-h-screen bg-gradient-kerala flex items-center justify-center p-6">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-repeat" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
          }}></div>
        </div>
        
        <Card className="bg-card/95 backdrop-blur-sm shadow-strong max-w-2xl w-full text-center">
          <CardContent className="p-8">
            <div className="mb-6">
              <div className="w-24 h-24 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
                <Building className="w-12 h-12 text-primary-foreground" />
              </div>
              <div className="flex items-center gap-2 justify-center mb-4">
                <h1 className="text-3xl font-bold text-primary">Thank You!</h1>
                <SpeakButton text="Thank You!" />
              </div>
              <div className="flex items-center gap-2 justify-center mb-6">
                <p className="text-lg text-muted-foreground">
                  for being a partner with the Government of Kerala
                </p>
                <SpeakButton text="for being a partner with the Government of Kerala" />
              </div>
            </div>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-2 justify-center">
                <p className="text-primary font-semibold">Company: {companyData.companyName}</p>
                <SpeakButton text={`Company: ${companyData.companyName}`} />
              </div>
              <div className="flex items-center gap-2 justify-center">
                <p className="text-muted-foreground">ID: {companyData.companyId}</p>
                <SpeakButton text={`ID: ${companyData.companyId}`} />
              </div>
            </div>

            <Button 
              className="bg-gradient-primary hover:scale-105 transition-transform duration-300 shadow-medium"
              onClick={() => {
                localStorage.setItem(`company_thankyou_${companyData.companyId}`, 'true');
                setShowThankYou(false);
              }}
            >
              Continue to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-card">
      {/* Header */}
      <header className="bg-gradient-primary text-primary-foreground shadow-strong">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-lg flex items-center justify-center">
              <Building className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold">Health+ Company Portal</h1>
                <SpeakButton text="Health+ Company Portal" className="text-primary-foreground" />
              </div>
              <div className="flex items-center gap-2">
                <p className="text-sm opacity-90">{companyData.companyName}</p>
                <SpeakButton text={companyData.companyName} className="text-primary-foreground" />
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium">Company ID: {companyData.companyId}</p>
                <SpeakButton text={`Company ID: ${companyData.companyId}`} className="text-primary-foreground" />
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-6">
        <Tabs defaultValue="analytics" className="space-y-6">
          {/* Navigation Tabs */}
          <TabsList className="grid w-full grid-cols-3 bg-card border-card-border">
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="flex items-center gap-1">
                Analysis
                <SpeakButton text="Analysis" />
              </span>
            </TabsTrigger>
            <TabsTrigger value="search" className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              <span className="flex items-center gap-1">
                Search Employee
                <SpeakButton text="Search Employee" />
              </span>
            </TabsTrigger>
            <TabsTrigger value="resigned" className="flex items-center gap-2">
              <TrendingDown className="w-4 h-4" />
              <span className="flex items-center gap-1">
                Resigned Employees
                <SpeakButton text="Resigned Employees" />
              </span>
            </TabsTrigger>
          </TabsList>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-muted-foreground">Total Employees</p>
                        <SpeakButton text="Total Employees" />
                      </div>
                      <p className="text-3xl font-bold text-primary">{companyData.totalEmployees}</p>
                    </div>
                    <Users className="w-8 h-8 text-primary" />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-muted-foreground">With Diseases</p>
                        <SpeakButton text="With Diseases" />
                      </div>
                      <p className="text-3xl font-bold text-health-emergency">{companyData.employeesWithDiseases}</p>
                    </div>
                    <div className="w-8 h-8 bg-health-emergency/10 rounded-lg flex items-center justify-center">
                      <User className="w-5 h-5 text-health-emergency" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-muted-foreground">Cured</p>
                        <SpeakButton text="Cured" />
                      </div>
                      <p className="text-3xl font-bold text-health-success">{companyData.curedEmployees}</p>
                    </div>
                    <div className="w-8 h-8 bg-health-success/10 rounded-lg flex items-center justify-center">
                      <User className="w-5 h-5 text-health-success" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-muted-foreground">Chronic Diseases</p>
                        <SpeakButton text="Chronic Diseases" />
                      </div>
                      <p className="text-3xl font-bold text-health-warning">{companyData.chronicDiseases}</p>
                    </div>
                    <div className="w-8 h-8 bg-health-warning/10 rounded-lg flex items-center justify-center">
                      <User className="w-5 h-5 text-health-warning" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* State-wise Distribution */}
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    <span className="flex items-center gap-1">
                      Employees by Origin State
                      <SpeakButton text="Employees by Origin State" />
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {companyData.stateWiseEmployees.map((state, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{state.state}</span>
                            <SpeakButton text={state.state} />
                          </div>
                          <span className="font-bold text-primary">{state.count}</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-gradient-primary h-2 rounded-full" 
                            style={{ width: `${(state.count / companyData.totalEmployees) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Disease Breakdown */}
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    <span className="flex items-center gap-1">
                      Disease Distribution
                      <SpeakButton text="Disease Distribution" />
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {companyData.diseaseBreakdown.map((disease, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-health-primary/10 rounded-lg flex items-center justify-center text-xs font-bold">
                            {index + 1}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{disease.disease}</span>
                            <SpeakButton text={disease.disease} />
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-health-primary">{disease.count}</p>
                          <p className="text-xs text-muted-foreground">employees</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Working Employees List */}
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  <span className="flex items-center gap-1">
                    Working Employees List
                    <SpeakButton text="Working Employees List" />
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3 font-medium">
                          <div className="flex items-center gap-1">
                            Employee ID
                            <SpeakButton text="Employee ID" />
                          </div>
                        </th>
                        <th className="text-left p-3 font-medium">
                          <div className="flex items-center gap-1">
                            Name
                            <SpeakButton text="Name" />
                          </div>
                        </th>
                        <th className="text-left p-3 font-medium">
                          <div className="flex items-center gap-1">
                            Department
                            <SpeakButton text="Department" />
                          </div>
                        </th>
                        <th className="text-left p-3 font-medium">
                          <div className="flex items-center gap-1">
                            Position
                            <SpeakButton text="Position" />
                          </div>
                        </th>
                        <th className="text-left p-3 font-medium">
                          <div className="flex items-center gap-1">
                            State
                            <SpeakButton text="State" />
                          </div>
                        </th>
                        <th className="text-left p-3 font-medium">
                          <div className="flex items-center gap-1">
                            Health Status
                            <SpeakButton text="Health Status" />
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {companyData.workingEmployees.map((employee, index) => (
                        <tr key={index} className="border-b hover:bg-muted/50">
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <Badge variant="outline">{employee.id}</Badge>
                              <SpeakButton text={employee.id} />
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <span className="font-medium">{employee.name}</span>
                              <SpeakButton text={employee.name} />
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <span>{employee.department}</span>
                              <SpeakButton text={employee.department} />
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <span>{employee.position}</span>
                              <SpeakButton text={employee.position} />
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <Badge variant="secondary">{employee.state}</Badge>
                              <SpeakButton text={employee.state} />
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-1">
                              <Badge variant={employee.hasDisease ? "destructive" : "default"}>
                                {employee.hasDisease ? employee.disease : "Healthy"}
                              </Badge>
                              <SpeakButton text={employee.hasDisease ? employee.disease : "Healthy"} />
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Search Tab */}
          <TabsContent value="search" className="space-y-6">
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-6 h-6 text-health-primary" />
                  <span className="flex items-center gap-1">
                    Employee Search
                    <SpeakButton text="Employee Search" />
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <Input
                    placeholder="Enter Employee ID (e.g., EMP001, EMP002, JOEY321)"
                    value={searchEmployeeId}
                    onChange={(e) => setSearchEmployeeId(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={searchEmployee} className="bg-health-primary hover:bg-health-primary/90">
                    Search
                  </Button>
                </div>
              </CardContent>
            </Card>

            {selectedEmployee && (
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-6 h-6 text-health-primary" />
                    <span className="flex items-center gap-1">
                      Employee Details
                      <SpeakButton text="Employee Details" />
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="space-y-3">
                      <h3 className="font-semibold text-lg border-b pb-2 flex items-center gap-1">
                        Personal Information
                        <SpeakButton text="Personal Information" />
                      </h3>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Name:</span> {selectedEmployee.name}
                        <SpeakButton text={`Name: ${selectedEmployee.name}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">ID:</span> {selectedEmployee.id}
                        <SpeakButton text={`ID: ${selectedEmployee.id}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Age:</span> {selectedEmployee.age}
                        <SpeakButton text={`Age: ${selectedEmployee.age}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Mobile:</span> {selectedEmployee.mobile}
                        <SpeakButton text={`Mobile: ${selectedEmployee.mobile}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Email:</span> {selectedEmployee.email}
                        <SpeakButton text={`Email: ${selectedEmployee.email}`} />
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <h3 className="font-semibold text-lg border-b pb-2 flex items-center gap-1">
                        Work Information
                        <SpeakButton text="Work Information" />
                      </h3>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Department:</span> {selectedEmployee.department || 'N/A'}
                        <SpeakButton text={`Department: ${selectedEmployee.department || 'N/A'}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Position:</span> {selectedEmployee.position || 'N/A'}
                        <SpeakButton text={`Position: ${selectedEmployee.position || 'N/A'}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Join Date:</span> {selectedEmployee.joinDate || selectedEmployee.resignDate || 'N/A'}
                        <SpeakButton text={`Join Date: ${selectedEmployee.joinDate || selectedEmployee.resignDate || 'N/A'}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Status:</span> 
                        <Badge variant={selectedEmployee.status === "Active" ? "default" : "secondary"}>
                          {selectedEmployee.status || "Active"}
                        </Badge>
                        <SpeakButton text={`Status: ${selectedEmployee.status || "Active"}`} />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h3 className="font-semibold text-lg border-b pb-2 flex items-center gap-1">
                        Health Information
                        <SpeakButton text="Health Information" />
                      </h3>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">From State:</span> {selectedEmployee.state}
                        <SpeakButton text={`From State: ${selectedEmployee.state}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Blood Group:</span> {selectedEmployee.bloodGroup}
                        <SpeakButton text={`Blood Group: ${selectedEmployee.bloodGroup}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Health Status:</span>
                        <Badge variant={selectedEmployee.hasDisease ? "destructive" : "default"}>
                          {selectedEmployee.hasDisease ? selectedEmployee.disease : "Healthy"}
                        </Badge>
                        <SpeakButton text={`Health Status: ${selectedEmployee.hasDisease ? selectedEmployee.disease : "Healthy"}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Last Checkup:</span> {selectedEmployee.lastCheckup}
                        <SpeakButton text={`Last Checkup: ${selectedEmployee.lastCheckup}`} />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Resigned Employees Tab */}
          <TabsContent value="resigned" className="space-y-6">
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="w-6 h-6 text-health-emergency" />
                  <span className="flex items-center gap-1">
                    Resigned Employees Management
                    <SpeakButton text="Resigned Employees Management" />
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="flex items-center gap-2 justify-center">
                      <p className="text-2xl font-bold text-health-emergency">{companyData.totalResignedEmployees}</p>
                      <SpeakButton text={`${companyData.totalResignedEmployees} total resigned`} />
                    </div>
                    <p className="text-sm text-muted-foreground">Total Resigned</p>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="flex items-center gap-2 justify-center">
                      <p className="text-2xl font-bold text-health-warning">{companyData.resignedWithDiseases}</p>
                      <SpeakButton text={`${companyData.resignedWithDiseases} with ongoing diseases`} />
                    </div>
                    <p className="text-sm text-muted-foreground">With Ongoing Diseases</p>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="flex items-center gap-2 justify-center">
                      <p className="text-2xl font-bold text-health-success">{companyData.totalResignedEmployees - companyData.resignedWithDiseases}</p>
                      <SpeakButton text={`${companyData.totalResignedEmployees - companyData.resignedWithDiseases} healthy`} />
                    </div>
                    <p className="text-sm text-muted-foreground">Healthy</p>
                  </div>
                </div>

                <div className="space-y-4">
                  {companyData.resignedEmployees.map((employee, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{employee.id}</span>
                          <SpeakButton text={employee.id} />
                        </div>
                        <div className="flex items-center gap-2">
                          <span>{employee.name}</span>
                          <SpeakButton text={employee.name} />
                        </div>
                        <Badge variant={employee.hasDisease ? "destructive" : "default"}>
                          {employee.disease}
                        </Badge>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">Resigned: {employee.resignDate}</span>
                          <SpeakButton text={`Resigned: ${employee.resignDate}`} />
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteEmployee(employee.id)}
                        className="flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete Record
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default CompanyDashboard;