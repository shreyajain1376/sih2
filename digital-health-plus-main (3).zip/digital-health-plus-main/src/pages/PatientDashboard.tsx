import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, Home, Calendar, FileText, Bot, MapPin, Video, User, LogOut, Stethoscope, Phone } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import SpeakButton from "@/components/SpeakButton";

const PatientDashboard = () => {
  const [chatMessage, setChatMessage] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [chatHistory, setChatHistory] = useState([
    {
      type: "ai",
      message: "Hello! I'm your AI Health Assistant. How can I help you today? I can suggest hospitals, medicines, or help you find specialists."
    }
  ]);

  const navigate = useNavigate();
  const { toast } = useToast();

  // Kerala cities
  const keralaCities = [
    "Thiruvananthapuram", "Kochi", "Kozhikode", "Kottayam", "Kollam", "Thrissur", 
    "Alappuzha", "Kannur", "Kasaragod", "Idukki", "Malappuram", "Palakkad", 
    "Pathanamthitta", "Wayanad"
  ];

  // Sample hospitals data
  const hospitals = [
    {
      name: "Government Medical College Hospital",
      city: "Thiruvananthapuram",
      phone: "+91-471-2528073",
      reviews: "4.2/5 (1,245 reviews)",
      address: "Medical College P.O, Thiruvananthapuram, Kerala 695011",
      specialties: ["Cardiology", "Neurology", "Orthopedics", "General Medicine"]
    },
    {
      name: "Ernakulam General Hospital",
      city: "Kochi",
      phone: "+91-484-2376101",
      reviews: "4.0/5 (987 reviews)",
      address: "Ernakulam, Kochi, Kerala 682018",
      specialties: ["Pediatrics", "Gynecology", "Emergency Medicine", "Surgery"]
    }
  ];

  // Get current patient data
  const currentPatientId = localStorage.getItem('currentPatientId');
  const patientData = currentPatientId ? JSON.parse(localStorage.getItem(`patient_${currentPatientId}`) || '{}') : {};

  const handleChatSubmit = () => {
    if (!chatMessage.trim()) return;

    // Add user message
    const newChatHistory = [...chatHistory, { type: "user", message: chatMessage }];
    
    // Simple AI response logic
    let aiResponse = "";
    const message = chatMessage.toLowerCase();
    
    if (message.includes("hospital") || message.includes("doctor")) {
      aiResponse = "I can help you find the best hospitals in Kerala. Please specify your city or the type of specialist you need. For emergency care, I recommend contacting the nearest government hospital immediately.";
    } else if (message.includes("medicine") || message.includes("drug")) {
      aiResponse = "For medication information, I recommend consulting with a qualified pharmacist or doctor. If you need immediate help, please contact your nearest hospital or healthcare provider.";
    } else if (message.includes("appointment")) {
      aiResponse = "You can book appointments through the Appointments tab. Choose between in-person consultation at government hospitals or online consultation with available doctors.";
    } else {
      aiResponse = "I'm here to help with your health-related queries. You can ask me about hospitals, medicines, booking appointments, or finding specialists in Kerala.";
    }

    newChatHistory.push({ type: "ai", message: aiResponse });
    setChatHistory(newChatHistory);
    setChatMessage("");
  };

  const handleLogout = () => {
    localStorage.removeItem('currentPatientId');
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out"
    });
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-card">
      {/* Header */}
      <header className="bg-gradient-primary text-primary-foreground shadow-strong">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold">Health+</h1>
                <SpeakButton text="Health Plus" />
              </div>
              <div className="flex items-center gap-2">
                <p className="text-sm opacity-90">Patient Dashboard</p>
                <SpeakButton text="Patient Dashboard" />
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium">Welcome, {patientData.name || 'Patient'}</p>
              <p className="text-xs opacity-75">ID: {currentPatientId}</p>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-6">
        <Tabs defaultValue="home" className="space-y-6">
          {/* Navigation Tabs */}
          <TabsList className="grid w-full grid-cols-3 bg-card border-card-border">
            <TabsTrigger value="home" className="flex items-center gap-2">
              <Home className="w-4 h-4" />
              Home
            </TabsTrigger>
            <TabsTrigger value="appointments" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Appointments
            </TabsTrigger>
            <TabsTrigger value="health-records" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Health Records
            </TabsTrigger>
          </TabsList>

          {/* Home Tab */}
          <TabsContent value="home" className="space-y-6">
            {/* Welcome Card */}
            <Card className="bg-gradient-health text-primary-foreground shadow-glow">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-2">Welcome to Your Health Dashboard</h2>
                <p className="text-primary-foreground/90">
                  Access your health records, book appointments, and get AI-powered health assistance.
                </p>
              </CardContent>
            </Card>

            {/* AI Nurse Chat */}
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-6 h-6 text-health-primary" />
                  AI Health Assistant
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Chat History */}
                <div className="h-64 overflow-y-auto space-y-3 p-4 bg-muted/50 rounded-lg">
                  {chatHistory.map((chat, index) => (
                    <div key={index} className={`flex ${chat.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        chat.type === 'user' 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-health-primary/10 text-health-primary border border-health-primary/20'
                      }`}>
                        <p className="text-sm">{chat.message}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Chat Input */}
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Ask about hospitals, medicines, or health advice..."
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    className="flex-1 min-h-[40px] max-h-[120px]"
                    onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleChatSubmit())}
                  />
                  <Button onClick={handleChatSubmit} className="bg-health-primary hover:bg-health-primary/90">
                    Send
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Appointments Tab */}
          <TabsContent value="appointments" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* In-Person Consultation */}
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Stethoscope className="w-6 h-6 text-health-primary" />
                    In-Person Consultation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Select City in Kerala:</label>
                    <Select value={selectedCity} onValueChange={setSelectedCity}>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Choose your city" />
                      </SelectTrigger>
                      <SelectContent className="bg-background max-h-48">
                        {keralaCities.map((city) => (
                          <SelectItem key={city} value={city}>{city}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedCity && (
                    <div className="space-y-3">
                      <h4 className="font-semibold text-sm">Government Hospitals in {selectedCity}:</h4>
                      {hospitals
                        .filter(hospital => hospital.city === selectedCity)
                        .map((hospital, index) => (
                          <div key={index} className="p-3 border border-card-border rounded-lg space-y-2">
                            <h5 className="font-semibold">{hospital.name}</h5>
                            <div className="text-sm text-muted-foreground space-y-1">
                              <p className="flex items-center gap-2">
                                <Phone className="w-3 h-3" />
                                {hospital.phone}
                              </p>
                              <p className="flex items-center gap-2">
                                <MapPin className="w-3 h-3" />
                                {hospital.address}
                              </p>
                              <p>⭐ {hospital.reviews}</p>
                              <div className="flex flex-wrap gap-1 mt-2">
                                {hospital.specialties.map((specialty, idx) => (
                                  <Badge key={idx} variant="secondary" className="text-xs">
                                    {specialty}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <Button className="w-full bg-health-success hover:bg-health-success/90">
                              Book Appointment
                            </Button>
                          </div>
                        ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Online Consultation */}
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Video className="w-6 h-6 text-health-primary" />
                    Online Consultation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Connect with doctors via video call from the comfort of your home.
                  </p>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Select City for Online Doctors:</label>
                    <Select>
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Choose city" />
                      </SelectTrigger>
                      <SelectContent className="bg-background max-h-48">
                        {keralaCities.map((city) => (
                          <SelectItem key={city} value={city}>{city}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="p-4 bg-health-primary/5 rounded-lg border border-health-primary/20">
                    <h4 className="font-semibold text-health-primary mb-2">Available Online Doctors</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between items-center">
                        <span>Dr. Rajesh Kumar (General Medicine)</span>
                        <Badge className="bg-health-success">Available</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Dr. Priya Nair (Pediatrics)</span>
                        <Badge className="bg-health-warning">Busy</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Dr. Kumar Menon (Cardiology)</span>
                        <Badge className="bg-health-success">Available</Badge>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-health-primary hover:bg-health-primary/90">
                    Book Video Consultation
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Health Records Tab */}
          <TabsContent value="health-records" className="space-y-6">
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-6 h-6 text-health-primary" />
                  Your Health Records
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Personal Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h3 className="font-semibold text-lg border-b pb-2">Personal Information</h3>
                    <div className="space-y-2 text-sm">
                      <p><span className="font-medium">Name:</span> {patientData.name}</p>
                      <p><span className="font-medium">Age:</span> {patientData.age} years</p>
                      <p><span className="font-medium">Date of Birth:</span> {patientData.dateOfBirth}</p>
                      <p><span className="font-medium">Blood Group:</span> {patientData.bloodGroup}</p>
                      <p><span className="font-medium">Height:</span> {patientData.height} cm</p>
                      <p><span className="font-medium">Weight:</span> {patientData.weight} kg</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h3 className="font-semibold text-lg border-b pb-2">Contact Information</h3>
                    <div className="space-y-2 text-sm">
                      <p><span className="font-medium">Mobile:</span> +91 {patientData.mobile}</p>
                      <p><span className="font-medium">Email:</span> {patientData.email || 'Not provided'}</p>
                      <p><span className="font-medium">From State:</span> {patientData.fromState}</p>
                      <p><span className="font-medium">Moved to Kerala:</span> {patientData.yearMovedToKerala}</p>
                    </div>
                  </div>
                </div>

                {/* Health History */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-lg border-b pb-2">Health History</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-medium mb-2">Recent Illness (1-3 months)</h4>
                      <p className="text-sm capitalize">{patientData.recentIllness || 'No'}</p>
                      {patientData.diseaseDetails && (
                        <div className="mt-2 text-sm space-y-1">
                          <p><span className="font-medium">Disease:</span> {patientData.diseaseDetails.diseaseName}</p>
                          <p><span className="font-medium">Location:</span> {patientData.diseaseDetails.location}</p>
                          <p><span className="font-medium">Treatment:</span> {patientData.diseaseDetails.treatment}</p>
                        </div>
                      )}
                    </div>

                    <div className="p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-medium mb-2">Chronic Diseases</h4>
                      <p className="text-sm capitalize">{patientData.chronicDiseases || 'No'}</p>
                      {patientData.chronicDiseaseDetails && (
                        <div className="mt-2 text-sm">
                          <p><span className="font-medium">Types:</span> {patientData.chronicDiseaseDetails.type?.join(', ')}</p>
                          {patientData.chronicDiseaseDetails.otherDisease && (
                            <p><span className="font-medium">Other:</span> {patientData.chronicDiseaseDetails.otherDisease}</p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium mb-2">COVID-19 Vaccination</h4>
                    <p className="text-sm capitalize">{patientData.covidVaccination || 'Not specified'}</p>
                    {patientData.vaccinationCertificate && (
                      <p className="text-sm text-health-success mt-1">✓ Certificate uploaded</p>
                    )}
                  </div>
                </div>

                {/* Consultation History */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-lg border-b pb-2">Consultation History</h3>
                  <div className="text-center py-8 text-muted-foreground">
                    <Calendar className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No consultations yet. Book your first appointment above!</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default PatientDashboard;