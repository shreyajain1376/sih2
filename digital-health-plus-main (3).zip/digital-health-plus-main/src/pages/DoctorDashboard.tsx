import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, User, Calendar, FileText, LogOut, Stethoscope, Search, Star } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import SpeakButton from "@/components/SpeakButton";

const DoctorDashboard = () => {
  const [searchPatientId, setSearchPatientId] = useState("");
  const [searchPatientName, setSearchPatientName] = useState("");
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [consultationNotes, setConsultationNotes] = useState("");

  const navigate = useNavigate();
  const { toast } = useToast();

  // Sample appointments data
  const appointments = [
    {
      id: "1",
      patientId: "ABCDE12345678",
      patientName: "Rajesh Kumar",
      time: "10:00 AM",
      date: "2024-01-15",
      type: "In-person",
      status: "Completed"
    },
    {
      id: "2",
      patientId: "FGHIJ98765432",
      patientName: "Priya Nair",
      time: "2:30 PM",
      date: "2024-01-15",
      type: "Online",
      status: "Upcoming"
    }
  ];

  // Sample feedback data
  const feedback = [
    {
      patientId: "ABCDE12345678",
      patientName: "Rajesh Kumar",
      rating: 5,
      comment: "Excellent consultation. Doctor was very thorough and helpful.",
      date: "2024-01-14"
    },
    {
      patientId: "KLMNO11111111",
      patientName: "Meera Thomas",
      rating: 4,
      comment: "Good experience. Got proper guidance for my condition.",
      date: "2024-01-13"
    }
  ];

  const searchPatient = () => {
    if (!searchPatientId && !searchPatientName) {
      toast({
        title: "Search Required",
        description: "Please enter either Patient ID or Name",
        variant: "destructive"
      });
      return;
    }

    // Search for patient (in real app, this would be an API call)
    const patientData = localStorage.getItem(`patient_${searchPatientId}`);
    if (patientData) {
      setSelectedPatient(JSON.parse(patientData));
      toast({
        title: "Patient Found",
        description: "Patient records loaded successfully"
      });
    } else {
      toast({
        title: "Patient Not Found",
        description: "No patient found with the given ID",
        variant: "destructive"
      });
      setSelectedPatient(null);
    }
  };

  const updateHealthRecord = () => {
    if (!selectedPatient || !consultationNotes.trim()) {
      toast({
        title: "Missing Information",
        description: "Please select a patient and add consultation notes",
        variant: "destructive"
      });
      return;
    }

    // Update patient record with consultation notes
    const updatedPatient = {
      ...selectedPatient,
      consultations: [
        ...(selectedPatient.consultations || []),
        {
          date: new Date().toISOString(),
          doctorId: "A42P0910", // Sample doctor ID
          notes: consultationNotes,
          type: "General Consultation"
        }
      ]
    };

    localStorage.setItem(`patient_${searchPatientId}`, JSON.stringify(updatedPatient));
    
    toast({
      title: "Record Updated",
      description: "Patient health record updated successfully"
    });

    setConsultationNotes("");
    setSelectedPatient(updatedPatient);
  };

  const handleLogout = () => {
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out"
    });
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-card">
      {/* Header */}
      <header className="bg-gradient-primary text-primary-foreground shadow-strong">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold">Health+</h1>
                <SpeakButton text="Health Plus" />
              </div>
              <div className="flex items-center gap-2">
                <p className="text-sm opacity-90">Doctor Dashboard</p>
                <SpeakButton text="Doctor Dashboard" />
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium">Dr. Rajesh Kumar</p>
              <p className="text-xs opacity-75">ID: A42P0910</p>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-6">
        <Tabs defaultValue="patients" className="space-y-6">
          {/* Navigation Tabs */}
          <TabsList className="grid w-full grid-cols-3 bg-card border-card-border">
            <TabsTrigger value="patients" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Patient Records
            </TabsTrigger>
            <TabsTrigger value="appointments" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Appointments
            </TabsTrigger>
            <TabsTrigger value="feedback" className="flex items-center gap-2">
              <Star className="w-4 h-4" />
              Feedback
            </TabsTrigger>
          </TabsList>

          {/* Patient Records Tab */}
          <TabsContent value="patients" className="space-y-6">
            {/* Patient Search */}
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-6 h-6 text-health-primary" />
                  Patient Search
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Patient ID</label>
                    <Input
                      placeholder="Enter Patient ID"
                      value={searchPatientId}
                      onChange={(e) => setSearchPatientId(e.target.value)}
                      className="bg-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Patient Name</label>
                    <Input
                      placeholder="Enter Patient Name"
                      value={searchPatientName}
                      onChange={(e) => setSearchPatientName(e.target.value)}
                      className="bg-background"
                    />
                  </div>
                  <div className="flex items-end">
                    <Button 
                      onClick={searchPatient}
                      className="w-full bg-health-primary hover:bg-health-primary/90"
                    >
                      Search Patient
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Patient Details */}
            {selectedPatient && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="shadow-medium">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-6 h-6 text-health-primary" />
                      Patient Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="font-medium">Name:</p>
                        <p>{selectedPatient.name}</p>
                      </div>
                      <div>
                        <p className="font-medium">Age:</p>
                        <p>{selectedPatient.age} years</p>
                      </div>
                      <div>
                        <p className="font-medium">Blood Group:</p>
                        <p>{selectedPatient.bloodGroup}</p>
                      </div>
                      <div>
                        <p className="font-medium">Mobile:</p>
                        <p>+91 {selectedPatient.mobile}</p>
                      </div>
                      <div>
                        <p className="font-medium">Height:</p>
                        <p>{selectedPatient.height} cm</p>
                      </div>
                      <div>
                        <p className="font-medium">Weight:</p>
                        <p>{selectedPatient.weight} kg</p>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold mb-2">Health History</h4>
                      <div className="space-y-2 text-sm">
                        <p><span className="font-medium">Recent Illness:</span> {selectedPatient.recentIllness}</p>
                        <p><span className="font-medium">Chronic Diseases:</span> {selectedPatient.chronicDiseases}</p>
                        <p><span className="font-medium">COVID Vaccination:</span> {selectedPatient.covidVaccination}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-medium">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-6 h-6 text-health-primary" />
                      Update Health Record
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Consultation Notes</label>
                      <Textarea
                        placeholder="Enter consultation notes, diagnosis, treatment plan, etc."
                        value={consultationNotes}
                        onChange={(e) => setConsultationNotes(e.target.value)}
                        className="min-h-32 bg-background"
                      />
                    </div>

                    <Button 
                      onClick={updateHealthRecord}
                      className="w-full bg-health-success hover:bg-health-success/90"
                    >
                      Update Health Record
                    </Button>

                    {/* Previous Consultations */}
                    {selectedPatient.consultations && selectedPatient.consultations.length > 0 && (
                      <div className="pt-4 border-t">
                        <h4 className="font-semibold mb-2">Previous Consultations</h4>
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {selectedPatient.consultations.map((consultation, index) => (
                            <div key={index} className="p-3 bg-muted/50 rounded-lg text-sm">
                              <p className="font-medium">{new Date(consultation.date).toLocaleDateString()}</p>
                              <p className="text-muted-foreground">{consultation.notes}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Appointments Tab */}
          <TabsContent value="appointments" className="space-y-6">
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-6 h-6 text-health-primary" />
                  Today's Appointments
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {appointments.map((appointment) => (
                    <div key={appointment.id} className="flex items-center justify-between p-4 border border-card-border rounded-lg">
                      <div className="space-y-1">
                        <p className="font-semibold">{appointment.patientName}</p>
                        <p className="text-sm text-muted-foreground">ID: {appointment.patientId}</p>
                        <p className="text-sm">{appointment.time} | {appointment.type}</p>
                      </div>
                      <div className="text-right space-y-2">
                        <Badge variant={appointment.status === 'Completed' ? 'default' : 'secondary'}>
                          {appointment.status}
                        </Badge>
                        {appointment.status === 'Upcoming' && (
                          <div className="space-x-2">
                            <Button size="sm" variant="outline">
                              {appointment.type === 'Online' ? 'Start Video Call' : 'Mark Present'}
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Feedback Tab */}
          <TabsContent value="feedback" className="space-y-6">
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-6 h-6 text-health-primary" />
                  Patient Feedback
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {feedback.map((review, index) => (
                    <div key={index} className="p-4 border border-card-border rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold">{review.patientName}</p>
                          <p className="text-sm text-muted-foreground">ID: {review.patientId}</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted'
                                }`}
                              />
                            ))}
                          </div>
                          <p className="text-xs text-muted-foreground">{review.date}</p>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{review.comment}</p>
                    </div>
                  ))}
                </div>

                {/* Average Rating */}
                <div className="mt-6 pt-6 border-t text-center">
                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-health-success/10 rounded-lg">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">Average Rating: 4.5/5</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default DoctorDashboard;