import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Play, Heart, Shield, Users, Activity } from "lucide-react";
import { useNavigate } from "react-router-dom";
import SpeakButton from "@/components/SpeakButton";

const WelcomePage = () => {
  const [showTutorial, setShowTutorial] = useState(false);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-kerala relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-72 h-72 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-health-primary rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center shadow-glow">
            <Heart className="w-7 h-7 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">Health+</h1>
            <p className="text-sm text-primary-foreground/80">Digital Health Records</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-6">
        <div className="text-center max-w-4xl mx-auto space-y-8">
          {/* Welcome Title */}
          <div className="space-y-4 animate-fade-in">
            <Badge variant="secondary" className="px-6 py-2 text-lg font-semibold">
              <Shield className="w-5 h-5 mr-2" />
              Powered by Government of Kerala
            </Badge>
            
            <div className="flex items-center gap-2 justify-center">
              <h1 className="text-6xl md:text-8xl font-bold text-primary-foreground drop-shadow-lg">
                Welcome to <span className="text-secondary">Health+</span>
              </h1>
              <SpeakButton text="Welcome to Health Plus" />
            </div>
            
            <div className="flex items-center gap-2 justify-center">
              <p className="text-xl md:text-2xl text-primary-foreground/90 max-w-3xl mx-auto leading-relaxed">
                Comprehensive Digital Health Record Management System for migrant workers in Kerala, 
                aligned with <span className="font-semibold text-secondary">Sustainable Development Goals</span>
              </p>
              <SpeakButton text="Comprehensive Digital Health Record Management System for migrant workers in Kerala, aligned with Sustainable Development Goals" />
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-12 animate-slide-up">
            <Card className="p-6 bg-card/90 backdrop-blur-sm border-card-border shadow-medium hover:shadow-strong transition-all duration-300">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-health-primary rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold text-lg">For Everyone</h3>
              </div>
              <p className="text-muted-foreground">Patients, Doctors, Administrators, and Government Officials</p>
            </Card>

            <Card className="p-6 bg-card/90 backdrop-blur-sm border-card-border shadow-medium hover:shadow-strong transition-all duration-300">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-health-success rounded-lg flex items-center justify-center">
                  <Activity className="w-5 h-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold text-lg">Smart Records</h3>
              </div>
              <p className="text-muted-foreground">AI-powered health tracking and appointment management</p>
            </Card>

            <Card className="p-6 bg-card/90 backdrop-blur-sm border-card-border shadow-medium hover:shadow-strong transition-all duration-300">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-health-warning rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold text-lg">Secure & Safe</h3>
              </div>
              <p className="text-muted-foreground">Government-grade security for your health data</p>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center animate-slide-up">
            <Button 
              size="lg" 
              className="px-12 py-6 text-lg font-semibold bg-gradient-primary hover:scale-105 transition-transform duration-300 shadow-glow"
              onClick={() => navigate('/login')}
            >
              Continue to Login / Sign Up
            </Button>

            <Dialog open={showTutorial} onOpenChange={setShowTutorial}>
              <DialogTrigger asChild>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="px-12 py-6 text-lg font-semibold border-2 border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary transition-all duration-300"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Watch Tutorial
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle className="text-2xl">Health+ Tutorial Video</DialogTitle>
                </DialogHeader>
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="w-24 h-24 bg-health-primary rounded-full flex items-center justify-center mx-auto">
                      <Play className="w-12 h-12 text-primary-foreground" />
                    </div>
                    <p className="text-lg font-semibold">Tutorial Video Coming Soon</p>
                    <p className="text-muted-foreground">
                      This comprehensive tutorial will guide you through all features of Health+
                    </p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 text-center p-6 text-primary-foreground/70">
        <p>&copy; 2024 Government of Kerala. All rights reserved. | Health+ Digital Health Records</p>
      </footer>
    </div>
  );
};

export default WelcomePage;