import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Heart, User, UserCog, Stethoscope, Shield, Building } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import LanguageSelector from "@/components/LanguageSelector";
import SpeakButton from "@/components/SpeakButton";

type UserType = "patient" | "admin" | "doctor" | "government" | "company";

const LoginPage = () => {
  const [userType, setUserType] = useState<UserType>("patient");
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { toast } = useToast();

  const userTypeConfig = {
    patient: {
      icon: User,
      title: "Patient",
      placeholder: "Enter your unique ID (e.g., TAHSU56775556)",
      description: "Access your health records and appointments"
    },
    admin: {
      icon: UserCog,
      title: "Administrator",
      placeholder: "Enter your admin ID (e.g., ASDF223232)",
      description: "Manage system and user accounts"
    },
    doctor: {
      icon: Stethoscope,
      title: "Doctor",
      placeholder: "Enter your doctor ID (e.g., A42P0910)",
      description: "Access patient records and consultations"
    },
    government: {
      icon: Shield,
      title: "Government Official",
      placeholder: "Enter your official ID (e.g., M24K2610)",
      description: "Access comprehensive health data analytics"
    },
    company: {
      icon: Building,
      title: "Company",
      placeholder: "Enter your company ID (e.g., APS3Y10)",
      description: "Manage employee health records and analytics"
    }
  };

  const handleLogin = () => {
    if (!userId || !password) {
      toast({
        title: "Missing Information",
        description: "Please enter both ID and password",
        variant: "destructive"
      });
      return;
    }

    // In a real app, this would validate credentials
    toast({
      title: "Login Successful",
      description: `Welcome, ${userTypeConfig[userType].title}!`
    });

    // Navigate based on user type
    switch (userType) {
      case "patient":
        navigate("/dashboard/patient");
        break;
      case "doctor":
        navigate("/dashboard/doctor");
        break;
      case "government":
        navigate("/dashboard/government");
        break;
      case "admin":
        navigate("/dashboard/admin");
        break;
      case "company":
        navigate("/dashboard/company");
        break;
      default:
        navigate("/dashboard");
    }
  };

  const IconComponent = userTypeConfig[userType].icon;

  return (
    <div className="min-h-screen bg-gradient-kerala flex items-center justify-center p-6">
      {/* Language Selector */}
      <div className="absolute top-4 right-4 z-20">
        <LanguageSelector />
      </div>

      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-72 h-72 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
              <Heart className="w-8 h-8 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-primary-foreground">Health+</h1>
              <Badge variant="secondary" className="text-sm">
                Government of Kerala
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-2 justify-center">
            <h2 className="text-2xl font-semibold text-primary-foreground mb-2">
              Sign In to Your Account
            </h2>
            <SpeakButton text="Sign In to Your Account" />
          </div>
          <div className="flex items-center gap-2 justify-center">
            <p className="text-primary-foreground/80">
              Choose your role and enter your credentials
            </p>
            <SpeakButton text="Choose your role and enter your credentials" />
          </div>
        </div>

        <Card className="bg-card/95 backdrop-blur-sm border-card-border shadow-strong">
          <CardHeader className="text-center pb-4">
            <CardTitle className="flex items-center justify-center gap-2 text-xl">
              <IconComponent className="w-6 h-6 text-primary" />
              {userTypeConfig[userType].title} Login
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              {userTypeConfig[userType].description}
            </p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* User Type Selection */}
            <div className="space-y-2">
              <Label htmlFor="userType">Select Your Role</Label>
              <Select value={userType} onValueChange={(value) => setUserType(value as UserType)}>
                <SelectTrigger className="bg-background border-input">
                  <SelectValue placeholder="Choose your role" />
                </SelectTrigger>
                <SelectContent className="bg-background border-border">
                  <SelectItem value="patient">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Patient
                    </div>
                  </SelectItem>
                  <SelectItem value="doctor">
                    <div className="flex items-center gap-2">
                      <Stethoscope className="w-4 h-4" />
                      Doctor
                    </div>
                  </SelectItem>
                  <SelectItem value="admin">
                    <div className="flex items-center gap-2">
                      <UserCog className="w-4 h-4" />
                      Administrator
                    </div>
                  </SelectItem>
                  <SelectItem value="government">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4" />
                      Government Official
                    </div>
                  </SelectItem>
                  <SelectItem value="company">
                    <div className="flex items-center gap-2">
                      <Building className="w-4 h-4" />
                      Company
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* User ID */}
            <div className="space-y-2">
              <Label htmlFor="userId">User ID</Label>
              <Input
                id="userId"
                type="text"
                placeholder={userTypeConfig[userType].placeholder}
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                className="bg-background border-input"
              />
            </div>

            {/* Password */}
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-background border-input"
              />
            </div>

            {/* Login Button */}
            <Button 
              className="w-full bg-gradient-primary hover:scale-105 transition-transform duration-300 shadow-medium"
              onClick={handleLogin}
            >
              Sign In as {userTypeConfig[userType].title}
            </Button>

            {/* Register Link */}
            <div className="text-center pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground mb-2">
                Don't have an account?
              </p>
              <Button 
                variant="outline" 
                className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                onClick={() => navigate('/register')}
              >
                Register New Account
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Back to Welcome */}
        <div className="text-center mt-6">
          <Button 
            variant="ghost" 
            className="text-primary-foreground hover:text-secondary"
            onClick={() => navigate('/')}
          >
            ← Back to Welcome
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;