import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Heart, Key, CheckCircle, Eye, EyeOff } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import SpeakButton from "@/components/SpeakButton";

const SetPasswordPage = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const { patientId, patientData } = location.state || {};

  const validatePassword = (pwd: string) => {
    const minLength = pwd.length >= 8;
    const hasUpper = /[A-Z]/.test(pwd);
    const hasLower = /[a-z]/.test(pwd);
    const hasNumber = /\d/.test(pwd);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);
    
    return {
      minLength,
      hasUpper,
      hasLower,
      hasNumber,
      hasSpecial,
      isValid: minLength && hasUpper && hasLower && hasNumber && hasSpecial
    };
  };

  const passwordValidation = validatePassword(password);
  const passwordsMatch = password === confirmPassword && password.length > 0;

  const handleSetPassword = () => {
    if (!passwordValidation.isValid) {
      toast({
        title: "Invalid Password",
        description: "Please ensure your password meets all requirements",
        variant: "destructive"
      });
      return;
    }

    if (!passwordsMatch) {
      toast({
        title: "Passwords Don't Match",
        description: "Please ensure both passwords are identical",
        variant: "destructive"
      });
      return;
    }

    // Update patient data with password (in a real app, this would be hashed)
    const updatedPatientData = {
      ...patientData,
      password: password // In production, this should be hashed
    };

    // Update localStorage
    localStorage.setItem(`patient_${patientId}`, JSON.stringify(updatedPatientData));

    toast({
      title: "Registration Complete!",
      description: "Your account has been created successfully",
    });

    // Navigate to login page
    navigate('/login', { 
      state: { 
        message: "Registration successful! Please login with your credentials.",
        patientId 
      } 
    });
  };

  if (!patientId || !patientData) {
    return (
      <div className="min-h-screen bg-gradient-kerala flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="text-center p-8">
            <p className="text-lg mb-4">Invalid access. Please complete registration first.</p>
            <Button onClick={() => navigate('/register')}>
              Go to Registration
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-kerala flex items-center justify-center p-4">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-72 h-72 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
              <Heart className="w-8 h-8 text-primary-foreground" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-3xl font-bold text-primary-foreground">Health+</h1>
                <SpeakButton text="Health Plus" />
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-sm">
                  Account Setup
                </Badge>
                <SpeakButton text="Account Setup" />
              </div>
            </div>
          </div>
        </div>

        <Card className="bg-card/95 backdrop-blur-sm border-card-border shadow-strong">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-xl">
              <CheckCircle className="w-6 h-6 text-health-success" />
              Registration Successful!
            </CardTitle>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Your patient profile has been created
              </p>
              <div className="p-3 bg-health-success/10 rounded-lg border border-health-success/20">
                <p className="text-sm font-medium text-health-success">
                  Your Patient ID: <span className="font-bold text-lg">{patientId}</span>
                </p>
                <p className="text-xs text-health-success/80 mt-1">
                  Please save this ID for future logins
                </p>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="text-center">
              <Key className="w-12 h-12 text-primary mx-auto mb-2" />
              <h3 className="text-lg font-semibold">Set Your Password</h3>
              <p className="text-sm text-muted-foreground">
                Create a secure password to protect your health records
              </p>
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <Label htmlFor="password">Password *</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="bg-background pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                </Button>
              </div>
            </div>

            {/* Confirm Password Input */}
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password *</Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm your password"
                  className="bg-background pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                </Button>
              </div>
            </div>

            {/* Password Requirements */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Password Requirements:</Label>
              <div className="space-y-1 text-xs">
                {[
                  { key: 'minLength', text: 'At least 8 characters', valid: passwordValidation.minLength },
                  { key: 'hasUpper', text: 'One uppercase letter', valid: passwordValidation.hasUpper },
                  { key: 'hasLower', text: 'One lowercase letter', valid: passwordValidation.hasLower },
                  { key: 'hasNumber', text: 'One number', valid: passwordValidation.hasNumber },
                  { key: 'hasSpecial', text: 'One special character', valid: passwordValidation.hasSpecial }
                ].map((req) => (
                  <div key={req.key} className={`flex items-center gap-2 ${req.valid ? 'text-health-success' : 'text-muted-foreground'}`}>
                    <div className={`w-3 h-3 rounded-full ${req.valid ? 'bg-health-success' : 'bg-muted-foreground/30'}`} />
                    <span>{req.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Password Match Indicator */}
            {confirmPassword.length > 0 && (
              <div className={`flex items-center gap-2 text-xs ${passwordsMatch ? 'text-health-success' : 'text-health-emergency'}`}>
                <div className={`w-3 h-3 rounded-full ${passwordsMatch ? 'bg-health-success' : 'bg-health-emergency'}`} />
                <span>{passwordsMatch ? 'Passwords match' : 'Passwords do not match'}</span>
              </div>
            )}

            {/* Set Password Button */}
            <Button 
              className="w-full bg-gradient-health hover:scale-105 transition-transform duration-300 shadow-medium"
              onClick={handleSetPassword}
              disabled={!passwordValidation.isValid || !passwordsMatch}
            >
              Set Password & Complete Registration
            </Button>

            {/* Patient Information Summary */}
            <div className="pt-4 border-t border-border">
              <h4 className="text-sm font-semibold mb-2">Account Summary:</h4>
              <div className="text-xs text-muted-foreground space-y-1">
                <p><span className="font-medium">Name:</span> {patientData.name}</p>
                <p><span className="font-medium">Age:</span> {patientData.age} years</p>
                <p><span className="font-medium">Mobile:</span> +91 {patientData.mobile}</p>
                <p><span className="font-medium">Blood Group:</span> {patientData.bloodGroup}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Back Button */}
        <div className="text-center mt-6">
          <Button 
            variant="ghost" 
            className="text-primary-foreground hover:text-secondary"
            onClick={() => navigate('/health-record-form', { state: { formData: patientData } })}
          >
            ← Back to Health Records
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SetPasswordPage;