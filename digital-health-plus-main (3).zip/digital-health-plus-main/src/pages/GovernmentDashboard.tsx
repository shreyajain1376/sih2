import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, Search, User, BarChart3, LogOut, FileText, Calendar, Shield, Activity, Building, MapPin, Users, TrendingUp, CheckCircle, XCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import SpeakButton from "@/components/SpeakButton";

const GovernmentDashboard = () => {
  const [searchPatientId, setSearchPatientId] = useState("");
  const [searchPatientName, setSearchPatientName] = useState("");
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [selectedCompany, setSelectedCompany] = useState(null);

  const navigate = useNavigate();
  const { toast } = useToast();

  // Sample analytics data
  const analyticsData = {
    totalPatients: 12547,
    newRegistrations: 145,
    activeConsultations: 89,
    completedAppointments: 2341,
    topDiseases: [
      { name: "Hypertension", count: 1245 },
      { name: "Diabetes", count: 987 },
      { name: "Respiratory Issues", count: 654 },
      { name: "Cardiac Issues", count: 432 }
    ],
    stateWiseData: [
      { state: "Tamil Nadu", patients: 3245 },
      { state: "Karnataka", patients: 2876 },
      { state: "Andhra Pradesh", patients: 2134 },
      { state: "Maharashtra", patients: 1876 },
      { state: "Others", patients: 2416 }
    ],
    companies: [
      { 
        id: "APS3Y10", 
        name: "Kerala Construction Corp", 
        address: "123 Industrial Area, Kochi, Kerala 682001",
        totalEmployees: 1247,
        registeredEmployees: 1089,
        unregisteredEmployees: 158,
        outOfStateEmployees: 987,
        status: "approved"
      },
      { 
        id: "BXT4Z21", 
        name: "Malabar Textiles Ltd", 
        address: "456 Textile Park, Calicut, Kerala 673001",
        totalEmployees: 892,
        registeredEmployees: 743,
        unregisteredEmployees: 149,
        outOfStateEmployees: 634,
        status: "approved"
      },
      { 
        id: "CYU5A32", 
        name: "Spice Coast Exports", 
        address: "789 Export Zone, Cochin, Kerala 682002",
        totalEmployees: 567,
        registeredEmployees: 0,
        unregisteredEmployees: 567,
        outOfStateEmployees: 345,
        status: "pending"
      },
      { 
        id: "DFG6B43", 
        name: "Backwater Fisheries Ltd", 
        address: "321 Marine Drive, Alleppey, Kerala 688001",
        totalEmployees: 756,
        registeredEmployees: 678,
        unregisteredEmployees: 78,
        outOfStateEmployees: 456,
        status: "approved"
      },
      { 
        id: "EHI7C54", 
        name: "Rubber Processing Inc", 
        address: "654 Plantation Road, Kottayam, Kerala 686001",
        totalEmployees: 934,
        registeredEmployees: 823,
        unregisteredEmployees: 111,
        outOfStateEmployees: 567,
        status: "approved"
      },
      { 
        id: "FJK8D65", 
        name: "Coconut Oil Industries", 
        address: "987 Palm Avenue, Thrissur, Kerala 680001",
        totalEmployees: 445,
        registeredEmployees: 389,
        unregisteredEmployees: 56,
        outOfStateEmployees: 234,
        status: "approved"
      },
      { 
        id: "GKL9E76", 
        name: "Tea Plantation Works", 
        address: "147 Hill Station Road, Munnar, Kerala 685001",
        totalEmployees: 623,
        registeredEmployees: 0,
        unregisteredEmployees: 623,
        outOfStateEmployees: 489,
        status: "pending"
      },
      { 
        id: "HMN0F87", 
        name: "Shipbuilding Corporation", 
        address: "258 Naval Base, Kochi, Kerala 682003",
        totalEmployees: 1156,
        registeredEmployees: 1034,
        unregisteredEmployees: 122,
        outOfStateEmployees: 789,
        status: "approved"
      },
      { 
        id: "IPQ1G98", 
        name: "Cashew Processing Unit", 
        address: "369 Cashew Street, Kollam, Kerala 691001",
        totalEmployees: 378,
        registeredEmployees: 298,
        unregisteredEmployees: 80,
        outOfStateEmployees: 189,
        status: "approved"
      },
      { 
        id: "JRS2H09", 
        name: "Information Technology Park", 
        address: "741 Tech City, Thiruvananthapuram, Kerala 695001",
        totalEmployees: 2134,
        registeredEmployees: 1987,
        unregisteredEmployees: 147,
        outOfStateEmployees: 1456,
        status: "approved"
      },
      { 
        id: "KTU3I10", 
        name: "Ayurvedic Medicines Ltd", 
        address: "852 Herbal Park, Palakkad, Kerala 678001",
        totalEmployees: 423,
        registeredEmployees: 0,
        unregisteredEmployees: 423,
        outOfStateEmployees: 234,
        status: "pending"
      },
      { 
        id: "LVW4J21", 
        name: "Solar Energy Solutions", 
        address: "963 Green Energy Zone, Wayanad, Kerala 673001",
        totalEmployees: 589,
        registeredEmployees: 456,
        unregisteredEmployees: 133,
        outOfStateEmployees: 345,
        status: "approved"
      },
      { 
        id: "MXY5K32", 
        name: "Handicraft Exports", 
        address: "159 Craft Village, Kannur, Kerala 670001",
        totalEmployees: 312,
        registeredEmployees: 0,
        unregisteredEmployees: 312,
        outOfStateEmployees: 198,
        status: "pending"
      }
    ],
    companyDiseases: [
      { company: "Kerala Construction Corp", disease: "Back Problems", count: 89 },
      { company: "Kerala Construction Corp", disease: "Respiratory Issues", count: 67 },
      { company: "Malabar Textiles Ltd", disease: "Allergies", count: 45 },
      { company: "Malabar Textiles Ltd", disease: "Eye Strain", count: 34 }
    ]
  };

  const searchPatient = () => {
    if (!searchPatientId && !searchPatientName) {
      toast({
        title: "Search Required",
        description: "Please enter either Patient ID or Name",
        variant: "destructive"
      });
      return;
    }

    // Search for patient (in real app, this would be an API call)
    const patientData = localStorage.getItem(`patient_${searchPatientId}`);
    if (patientData) {
      setSelectedPatient(JSON.parse(patientData));
      toast({
        title: "Patient Found",
        description: "Patient records loaded successfully"
      });
    } else {
      toast({
        title: "Patient Not Found",
        description: "No patient found with the given ID",
        variant: "destructive"
      });
      setSelectedPatient(null);
    }
  };

  const handleLogout = () => {
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out"
    });
    navigate('/login');
  };

  const selectCompany = (company: any) => {
    setSelectedCompany(company);
    toast({
      title: "Company Selected",
      description: `Viewing details for ${company.name}`
    });
  };

  const approveCompany = (companyId: string) => {
    toast({
      title: "Company Approved",
      description: `Company ${companyId} has been approved for the Health+ platform`
    });
  };

  return (
    <div className="min-h-screen bg-gradient-card">
      {/* Header */}
      <header className="bg-gradient-primary text-primary-foreground shadow-strong">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground/20 rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Health+</h1>
              <p className="text-sm opacity-90">Government Official Dashboard</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium">Kerala Health Department</p>
              <p className="text-xs opacity-75">ID: M24K2610</p>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-6">
        <Tabs defaultValue="analytics" className="space-y-6">
          {/* Navigation Tabs */}
          <TabsList className="grid w-full grid-cols-4 bg-card border-card-border">
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="patients" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Patient Records
            </TabsTrigger>
            <TabsTrigger value="companies" className="flex items-center gap-2">
              <Building className="w-4 h-4" />
              Companies
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Reports
            </TabsTrigger>
          </TabsList>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Patients</p>
                      <p className="text-3xl font-bold text-health-primary">{analyticsData.totalPatients.toLocaleString()}</p>
                    </div>
                    <div className="w-12 h-12 bg-health-primary/10 rounded-lg flex items-center justify-center">
                      <User className="w-6 h-6 text-health-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">New Registrations</p>
                      <p className="text-3xl font-bold text-health-success">{analyticsData.newRegistrations}</p>
                    </div>
                    <div className="w-12 h-12 bg-health-success/10 rounded-lg flex items-center justify-center">
                      <Activity className="w-6 h-6 text-health-success" />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">This week</p>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Active Consultations</p>
                      <p className="text-3xl font-bold text-health-warning">{analyticsData.activeConsultations}</p>
                    </div>
                    <div className="w-12 h-12 bg-health-warning/10 rounded-lg flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-health-warning" />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Currently ongoing</p>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Completed Appointments</p>
                      <p className="text-3xl font-bold text-primary">{analyticsData.completedAppointments.toLocaleString()}</p>
                    </div>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Shield className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Total this month</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts and Detailed Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Top Diseases */}
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle>Most Common Health Issues</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analyticsData.topDiseases.map((disease, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-health-primary/10 rounded-lg flex items-center justify-center text-xs font-bold">
                            {index + 1}
                          </div>
                          <span className="font-medium">{disease.name}</span>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-health-primary">{disease.count}</p>
                          <p className="text-xs text-muted-foreground">patients</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* State-wise Data */}
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle>Migrant Workers by Origin State</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analyticsData.stateWiseData.map((state, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{state.state}</span>
                          <span className="font-bold text-primary">{state.patients}</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-health-primary h-2 rounded-full" 
                            style={{ width: `${(state.patients / analyticsData.totalPatients) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Patient Records Tab */}
          <TabsContent value="patients" className="space-y-6">
            {/* Patient Search */}
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-6 h-6 text-health-primary" />
                  Patient Search & Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Patient ID</label>
                    <Input
                      placeholder="Enter Patient ID"
                      value={searchPatientId}
                      onChange={(e) => setSearchPatientId(e.target.value)}
                      className="bg-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Patient Name</label>
                    <Input
                      placeholder="Enter Patient Name"
                      value={searchPatientName}
                      onChange={(e) => setSearchPatientName(e.target.value)}
                      className="bg-background"
                    />
                  </div>
                  <div className="flex items-end">
                    <Button 
                      onClick={searchPatient}
                      className="w-full bg-health-primary hover:bg-health-primary/90"
                    >
                      Search Patient
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Patient Details */}
            {selectedPatient && (
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-6 h-6 text-health-primary" />
                    Complete Patient Profile
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Personal Details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg border-b pb-2">Personal Information</h3>
                      <div className="space-y-2 text-sm">
                        <p><span className="font-medium">Name:</span> {selectedPatient.name}</p>
                        <p><span className="font-medium">Age:</span> {selectedPatient.age} years</p>
                        <p><span className="font-medium">Date of Birth:</span> {selectedPatient.dateOfBirth}</p>
                        <p><span className="font-medium">Blood Group:</span> {selectedPatient.bloodGroup}</p>
                        <p><span className="font-medium">Height:</span> {selectedPatient.height} cm</p>
                        <p><span className="font-medium">Weight:</span> {selectedPatient.weight} kg</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg border-b pb-2">Contact & Migration Info</h3>
                      <div className="space-y-2 text-sm">
                        <p><span className="font-medium">Mobile:</span> +91 {selectedPatient.mobile}</p>
                        <p><span className="font-medium">Email:</span> {selectedPatient.email || 'Not provided'}</p>
                        <p><span className="font-medium">Aadhar:</span> {selectedPatient.aadhar}</p>
                        <p><span className="font-medium">From State:</span> {selectedPatient.fromState}</p>
                        <p><span className="font-medium">Moved to Kerala:</span> {selectedPatient.yearMovedToKerala}</p>
                        <p><span className="font-medium">Registration Date:</span> {new Date(selectedPatient.registrationDate).toLocaleDateString()}</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg border-b pb-2">Health Status</h3>
                      <div className="space-y-2 text-sm">
                        <div>
                          <p className="font-medium">Recent Illness:</p>
                          <Badge variant={selectedPatient.recentIllness === 'yes' ? 'destructive' : 'default'}>
                            {selectedPatient.recentIllness}
                          </Badge>
                        </div>
                        <div>
                          <p className="font-medium">Chronic Diseases:</p>
                          <Badge variant={selectedPatient.chronicDiseases === 'yes' ? 'destructive' : 'default'}>
                            {selectedPatient.chronicDiseases}
                          </Badge>
                        </div>
                        <div>
                          <p className="font-medium">COVID Vaccination:</p>
                          <Badge variant={selectedPatient.covidVaccination === 'yes' ? 'default' : 'secondary'}>
                            {selectedPatient.covidVaccination}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Health Records */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg border-b pb-2">Detailed Health Records</h3>
                    
                    {selectedPatient.diseaseDetails && (
                      <div className="p-4 bg-health-emergency/5 border border-health-emergency/20 rounded-lg">
                        <h4 className="font-medium text-health-emergency mb-2">Recent Illness Details</h4>
                        <div className="text-sm space-y-1">
                          <p><span className="font-medium">Disease:</span> {selectedPatient.diseaseDetails.diseaseName}</p>
                          <p><span className="font-medium">Location of illness:</span> {selectedPatient.diseaseDetails.location}</p>
                          <p><span className="font-medium">Treatment location:</span> {selectedPatient.diseaseDetails.treatment}</p>
                          <p><span className="font-medium">Last checkup:</span> {selectedPatient.diseaseDetails.lastCheckup}</p>
                        </div>
                      </div>
                    )}

                    {selectedPatient.chronicDiseaseDetails && (
                      <div className="p-4 bg-health-warning/5 border border-health-warning/20 rounded-lg">
                        <h4 className="font-medium text-health-warning mb-2">Chronic Disease Details</h4>
                        <div className="text-sm space-y-1">
                          <p><span className="font-medium">Types:</span> {selectedPatient.chronicDiseaseDetails.type?.join(', ')}</p>
                          {selectedPatient.chronicDiseaseDetails.otherDisease && (
                            <p><span className="font-medium">Other conditions:</span> {selectedPatient.chronicDiseaseDetails.otherDisease}</p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Consultation History */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg border-b pb-2">Medical Consultation History</h3>
                    
                    {selectedPatient.consultations && selectedPatient.consultations.length > 0 ? (
                      <div className="space-y-3">
                        <p className="text-sm font-medium">Total Appointments: {selectedPatient.consultations.length}</p>
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {selectedPatient.consultations.map((consultation, index) => (
                            <div key={index} className="p-3 bg-muted/50 rounded-lg text-sm">
                              <div className="flex justify-between items-start mb-1">
                                <p className="font-medium">{new Date(consultation.date).toLocaleDateString()}</p>
                                <Badge variant="outline">{consultation.type}</Badge>
                              </div>
                              <p className="text-muted-foreground">Doctor ID: {consultation.doctorId}</p>
                              <p className="mt-1">{consultation.notes}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <Calendar className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>No consultations recorded yet</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Companies Tab */}
          <TabsContent value="companies" className="space-y-6">
            {/* Company Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Companies</p>
                      <p className="text-3xl font-bold text-primary">{analyticsData.companies.length}</p>
                    </div>
                    <Building className="w-8 h-8 text-primary" />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Approved Companies</p>
                      <p className="text-3xl font-bold text-health-success">
                        {analyticsData.companies.filter(c => c.status === 'approved').length}
                      </p>
                    </div>
                    <CheckCircle className="w-8 h-8 text-health-success" />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Pending Approval</p>
                      <p className="text-3xl font-bold text-health-warning">
                        {analyticsData.companies.filter(c => c.status === 'pending').length}
                      </p>
                    </div>
                    <XCircle className="w-8 h-8 text-health-warning" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Companies List */}
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="w-6 h-6 text-health-primary" />
                  Registered Companies
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analyticsData.companies.map((company, index) => (
                    <div key={index} className="border border-border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center">
                            <Building className="w-6 h-6 text-primary-foreground" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-lg">{company.name}</h3>
                            <p className="text-sm text-muted-foreground">ID: {company.id}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={company.status === 'approved' ? 'default' : 'secondary'}>
                            {company.status}
                          </Badge>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => selectCompany(company)}
                          >
                            View Details
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Total Employees</p>
                          <p className="font-bold text-primary">{company.totalEmployees}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Registered</p>
                          <p className="font-bold text-health-success">{company.registeredEmployees}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Unregistered</p>
                          <p className="font-bold text-health-warning">{company.unregisteredEmployees}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Out of State</p>
                          <p className="font-bold text-health-emergency">{company.outOfStateEmployees}</p>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground">{company.address}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Selected Company Details */}
            {selectedCompany && (
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-6 h-6 text-health-primary" />
                    {selectedCompany.name} - Detailed Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Employee Statistics */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <p className="text-2xl font-bold text-primary">{selectedCompany.totalEmployees}</p>
                      <p className="text-sm text-muted-foreground">Total Employees</p>
                    </div>
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <p className="text-2xl font-bold text-health-success">{selectedCompany.registeredEmployees}</p>
                      <p className="text-sm text-muted-foreground">Registered on Platform</p>
                    </div>
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <p className="text-2xl font-bold text-health-warning">{selectedCompany.unregisteredEmployees}</p>
                      <p className="text-sm text-muted-foreground">Not Yet Registered</p>
                    </div>
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <p className="text-2xl font-bold text-health-emergency">{selectedCompany.outOfStateEmployees}</p>
                      <p className="text-sm text-muted-foreground">From Other States</p>
                    </div>
                  </div>

                  {/* Disease Analysis for Company */}
                  <div>
                    <h4 className="font-semibold mb-3">Common Health Issues in {selectedCompany.name}</h4>
                    <div className="space-y-2">
                      {analyticsData.companyDiseases
                        .filter(d => d.company === selectedCompany.name)
                        .map((disease, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                            <span className="font-medium">{disease.disease}</span>
                            <span className="font-bold text-health-primary">{disease.count} employees</span>
                          </div>
                        ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Companies to be Approved */}
            <Card className="shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <XCircle className="w-6 h-6 text-health-warning" />
                  Companies Pending Approval
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analyticsData.companies
                    .filter(c => c.status === 'pending')
                    .map((company, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border border-border rounded-lg">
                        <div>
                          <h4 className="font-semibold">{company.name}</h4>
                          <p className="text-sm text-muted-foreground">ID: {company.id}</p>
                          <p className="text-sm text-muted-foreground">{company.address}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-right mr-4">
                            <p className="text-sm text-muted-foreground">Total Employees</p>
                            <p className="font-bold">{company.totalEmployees}</p>
                          </div>
                          <Button
                            onClick={() => approveCompany(company.id)}
                            className="bg-health-success hover:bg-health-success/90"
                          >
                            Approve Company
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-6 h-6 text-health-primary" />
                    Health Trends Report
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 bg-health-emergency/5 border border-health-emergency/20 rounded-lg">
                      <h4 className="font-medium text-health-emergency">High Priority Issues</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        15% increase in respiratory issues among migrant workers from construction sector
                      </p>
                    </div>
                    
                    <div className="p-3 bg-health-warning/5 border border-health-warning/20 rounded-lg">
                      <h4 className="font-medium text-health-warning">Vaccination Coverage</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        COVID-19 vaccination rate: 87% among registered migrant workers
                      </p>
                    </div>
                    
                    <div className="p-3 bg-health-success/5 border border-health-success/20 rounded-lg">
                      <h4 className="font-medium text-health-success">Positive Trends</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        Monthly health checkups increased by 23% this quarter
                      </p>
                    </div>
                  </div>
                  
                  <Button className="w-full" variant="outline">
                    Generate Full Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="shadow-medium">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-6 h-6 text-health-primary" />
                    System Usage Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Daily Active Users</span>
                      <span className="font-bold">1,234</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">New Registrations (Today)</span>
                      <span className="font-bold text-health-success">23</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Active Consultations</span>
                      <span className="font-bold text-health-warning">89</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">System Uptime</span>
                      <span className="font-bold text-health-success">99.9%</span>
                    </div>
                  </div>
                  
                  <Button className="w-full" variant="outline">
                    View Detailed Analytics
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default GovernmentDashboard;