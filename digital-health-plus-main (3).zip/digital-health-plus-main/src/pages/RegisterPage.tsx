import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Heart, Calendar, MapPin, Phone, CreditCard, Droplets } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import SpeakButton from "@/components/SpeakButton";

interface FormData {
  name: string;
  dateOfBirth: string;
  age: number;
  fromState: string;
  yearMovedToKerala: string;
  email: string;
  mobile: string;
  aadhar: string;
  bloodGroup: string;
  height: string;
  weight: string;
}

const RegisterPage = () => {
  const [step, setStep] = useState(1);
  const [showOTPModal, setShowOTPModal] = useState(false);
  const [otp, setOtp] = useState("");
  const [formData, setFormData] = useState<FormData>({
    name: "",
    dateOfBirth: "",
    age: 0,
    fromState: "",
    yearMovedToKerala: "",
    email: "",
    mobile: "",
    aadhar: "",
    bloodGroup: "",
    height: "",
    weight: ""
  });

  const navigate = useNavigate();
  const { toast } = useToast();

  const states = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat",
    "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Madhya Pradesh", "Maharashtra",
    "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim",
    "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
  ];

  const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

  const generateYears = () => {
    const years = [];
    for (let year = 2024; year >= 1960; year--) {
      years.push(year.toString());
    }
    return years;
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const handleDateOfBirthChange = (date: string) => {
    setFormData(prev => ({
      ...prev,
      dateOfBirth: date,
      age: calculateAge(date)
    }));
  };

  const handleAadharSubmit = () => {
    if (formData.aadhar.length !== 12) {
      toast({
        title: "Invalid Aadhar",
        description: "Aadhar number must be 12 digits",
        variant: "destructive"
      });
      return;
    }
    
    setShowOTPModal(true);
    toast({
      title: "OTP Sent",
      description: `Verification code sent to ${formData.mobile}`,
    });
  };

  const verifyOTP = () => {
    if (otp.length === 6) {
      setShowOTPModal(false);
      toast({
        title: "Verification Successful",
        description: "Mobile number verified successfully"
      });
      navigate('/health-record-form', { state: { formData } });
    } else {
      toast({
        title: "Invalid OTP",
        description: "Please enter a valid 6-digit OTP",
        variant: "destructive"
      });
    }
  };

  const nextStep = () => {
    if (step === 1) {
      if (!formData.name || !formData.dateOfBirth || !formData.fromState || !formData.yearMovedToKerala) {
        toast({
          title: "Incomplete Information",
          description: "Please fill all required fields",
          variant: "destructive"
        });
        return;
      }
    }
    setStep(step + 1);
  };

  const prevStep = () => setStep(step - 1);

  return (
    <div className="min-h-screen bg-gradient-kerala flex items-center justify-center p-4">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-72 h-72 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
              <Heart className="w-8 h-8 text-primary-foreground" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-3xl font-bold text-primary-foreground">Health+</h1>
                <SpeakButton text="Health Plus" />
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-sm">
                  New Patient Registration
                </Badge>
                <SpeakButton text="New Patient Registration" />
              </div>
            </div>
          </div>
          
          {/* Progress Indicator */}
          <div className="flex items-center justify-center gap-2 mb-4">
            {[1, 2, 3].map((num) => (
              <div key={num} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold
                  ${step >= num 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-primary-foreground/20 text-primary-foreground/60'
                  }`}>
                  {num}
                </div>
                {num < 3 && (
                  <div className={`w-12 h-1 mx-2 rounded
                    ${step > num ? 'bg-primary' : 'bg-primary-foreground/20'}`} 
                  />
                )}
              </div>
            ))}
          </div>
          
          <p className="text-primary-foreground/80">
            {step === 1 && "Personal Information"}
            {step === 2 && "Contact & ID Details"}
            {step === 3 && "Health Information"}
          </p>
        </div>

        <Card className="bg-card/95 backdrop-blur-sm border-card-border shadow-strong">
          <CardHeader>
            <CardTitle className="text-xl text-center">
              Step {step} of 3: Registration Form
            </CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {step === 1 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter your full name"
                    className="bg-background"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dob">Date of Birth *</Label>
                    <Input
                      id="dob"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => handleDateOfBirthChange(e.target.value)}
                      className="bg-background"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Age</Label>
                    <Input
                      value={formData.age || ""}
                      disabled
                      className="bg-muted"
                      placeholder="Calculated automatically"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>From which State *</Label>
                  <Select value={formData.fromState} onValueChange={(value) => setFormData(prev => ({ ...prev, fromState: value }))}>
                    <SelectTrigger className="bg-background">
                      <SelectValue placeholder="Select your state" />
                    </SelectTrigger>
                    <SelectContent className="bg-background max-h-48">
                      {states.map((state) => (
                        <SelectItem key={state} value={state}>{state}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Year you moved to Kerala *</Label>
                  <Select value={formData.yearMovedToKerala} onValueChange={(value) => setFormData(prev => ({ ...prev, yearMovedToKerala: value }))}>
                    <SelectTrigger className="bg-background">
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent className="bg-background max-h-48">
                      {generateYears().map((year) => (
                        <SelectItem key={year} value={year}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email ID (Optional)</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="Enter your email address"
                    className="bg-background"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mobile">Mobile Number *</Label>
                  <div className="flex gap-2">
                    <div className="flex items-center px-3 py-2 bg-muted rounded-md border">
                      <Phone className="w-4 h-4 mr-2" />
                      +91
                    </div>
                    <Input
                      id="mobile"
                      value={formData.mobile}
                      onChange={(e) => setFormData(prev => ({ ...prev, mobile: e.target.value }))}
                      placeholder="Enter 10-digit mobile number"
                      maxLength={10}
                      className="bg-background"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="aadhar">Aadhar Number *</Label>
                  <div className="flex gap-2">
                    <div className="flex items-center px-3 py-2 bg-muted rounded-md border">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <Input
                      id="aadhar"
                      value={formData.aadhar}
                      onChange={(e) => setFormData(prev => ({ ...prev, aadhar: e.target.value }))}
                      placeholder="Enter 12-digit Aadhar number"
                      maxLength={12}
                      className="bg-background"
                    />
                  </div>
                  {formData.aadhar.length === 12 && (
                    <Button 
                      className="w-full bg-health-primary hover:bg-health-primary/90"
                      onClick={handleAadharSubmit}
                    >
                      Verify Aadhar & Send OTP
                    </Button>
                  )}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Blood Group *</Label>
                  <Select value={formData.bloodGroup} onValueChange={(value) => setFormData(prev => ({ ...prev, bloodGroup: value }))}>
                    <SelectTrigger className="bg-background">
                      <div className="flex items-center gap-2">
                        <Droplets className="w-4 h-4 text-health-emergency" />
                        <SelectValue placeholder="Select blood group" />
                      </div>
                    </SelectTrigger>
                    <SelectContent className="bg-background">
                      {bloodGroups.map((group) => (
                        <SelectItem key={group} value={group}>{group}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm) *</Label>
                    <Input
                      id="height"
                      value={formData.height}
                      onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
                      placeholder="Enter height in cm"
                      type="number"
                      className="bg-background"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight (kg) *</Label>
                    <Input
                      id="weight"
                      value={formData.weight}
                      onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                      placeholder="Enter weight in kg"
                      type="number"
                      className="bg-background"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6">
              {step > 1 && (
                <Button variant="outline" onClick={prevStep} className="border-primary text-primary">
                  Previous
                </Button>
              )}
              
              {step < 3 ? (
                <Button 
                  className="ml-auto bg-gradient-primary hover:scale-105 transition-transform duration-300"
                  onClick={nextStep}
                >
                  Continue
                </Button>
              ) : (
                <Button 
                  className="ml-auto bg-gradient-health hover:scale-105 transition-transform duration-300"
                  onClick={() => navigate('/health-record-form', { state: { formData } })}
                >
                  Proceed to Health Records
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* OTP Modal */}
        {showOTPModal && (
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50">
            <Card className="w-full max-w-md mx-4 bg-card border-card-border">
              <CardHeader>
                <CardTitle className="text-center">Verify Mobile Number</CardTitle>
                <p className="text-center text-sm text-muted-foreground">
                  Enter the 6-digit OTP sent to {formData.mobile}
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="Enter OTP"
                  maxLength={6}
                  className="text-center text-lg tracking-widest"
                />
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setShowOTPModal(false)} className="flex-1">
                    Cancel
                  </Button>
                  <Button onClick={verifyOTP} className="flex-1 bg-health-success">
                    Verify
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Back to Login */}
        <div className="text-center mt-6">
          <Button 
            variant="ghost" 
            className="text-primary-foreground hover:text-secondary"
            onClick={() => navigate('/login')}
          >
            ← Back to Login
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;