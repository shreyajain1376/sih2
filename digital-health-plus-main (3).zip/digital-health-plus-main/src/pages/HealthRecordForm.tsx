import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Heart, FileText, Upload, CheckCircle } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import SpeakButton from "@/components/SpeakButton";

interface HealthData {
  recentIllness: string;
  diseaseDetails?: {
    diseaseName: string;
    location: string;
    treatment: string;
    lastCheckup: string;
  };
  chronicDiseases: string;
  chronicDiseaseDetails?: {
    type: string[];
    otherDisease?: string;
  };
  covidVaccination: string;
  vaccinationCertificate?: File;
}

const HealthRecordForm = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const formData = location.state?.formData;

  const [healthData, setHealthData] = useState<HealthData>({
    recentIllness: "",
    chronicDiseases: "",
    covidVaccination: ""
  });

  const [showDiseaseDetails, setShowDiseaseDetails] = useState(false);
  const [showChronicDetails, setShowChronicDetails] = useState(false);
  const [showVaccinationUpload, setShowVaccinationUpload] = useState(false);

  const handleRecentIllnessChange = (value: string) => {
    setHealthData(prev => ({ ...prev, recentIllness: value }));
    setShowDiseaseDetails(value === "yes");
  };

  const handleChronicDiseasesChange = (value: string) => {
    setHealthData(prev => ({ ...prev, chronicDiseases: value }));
    setShowChronicDetails(value === "yes");
  };

  const handleCovidVaccinationChange = (value: string) => {
    setHealthData(prev => ({ ...prev, covidVaccination: value }));
    setShowVaccinationUpload(value === "yes");
  };

  const handleChronicDiseaseSelection = (disease: string, checked: boolean) => {
    setHealthData(prev => ({
      ...prev,
      chronicDiseaseDetails: {
        ...prev.chronicDiseaseDetails,
        type: checked 
          ? [...(prev.chronicDiseaseDetails?.type || []), disease]
          : (prev.chronicDiseaseDetails?.type || []).filter(d => d !== disease)
      }
    }));
  };

  const generatePatientId = () => {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    let id = '';
    
    // Generate 5 random letters
    for (let i = 0; i < 5; i++) {
      id += letters.charAt(Math.floor(Math.random() * letters.length));
    }
    
    // Generate 8 random numbers
    for (let i = 0; i < 8; i++) {
      id += numbers.charAt(Math.floor(Math.random() * numbers.length));
    }
    
    return id;
  };

  const handleSubmit = () => {
    const patientId = generatePatientId();
    
    const completeRecord = {
      ...formData,
      ...healthData,
      patientId,
      registrationDate: new Date().toISOString()
    };

    // Store in localStorage (in a real app, this would go to a database)
    localStorage.setItem(`patient_${patientId}`, JSON.stringify(completeRecord));
    localStorage.setItem('currentPatientId', patientId);

    toast({
      title: "Registration Successful!",
      description: `Your unique patient ID is: ${patientId}`,
    });

    navigate('/set-password', { 
      state: { 
        patientId, 
        patientData: completeRecord 
      } 
    });
  };

  if (!formData) {
    return (
      <div className="min-h-screen bg-gradient-kerala flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="text-center p-8">
            <p className="text-lg mb-4">Please complete the registration form first.</p>
            <Button onClick={() => navigate('/register')}>
              Go to Registration
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-kerala p-4">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-72 h-72 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
              <Heart className="w-8 h-8 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-primary-foreground">Health+</h1>
              <Badge variant="secondary" className="text-sm">
                Health Record Assessment
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-2 justify-center">
            <h2 className="text-2xl font-semibold text-primary-foreground mb-2">
              Health Record Questions
            </h2>
            <SpeakButton text="Health Record Questions" />
          </div>
          <div className="flex items-center gap-2 justify-center">
            <p className="text-primary-foreground/80">
              Please provide accurate information about your health history
            </p>
            <SpeakButton text="Please provide accurate information about your health history" />
          </div>
        </div>

        <Card className="bg-card/95 backdrop-blur-sm border-card-border shadow-strong">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-6 h-6 text-health-primary" />
              Health Assessment Form
            </CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-8">
            {/* Question 1: Recent Illness */}
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  1. Have you fallen sick between 1-3 months?
                </h3>
                <RadioGroup 
                  value={healthData.recentIllness} 
                  onValueChange={handleRecentIllnessChange}
                  className="flex gap-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="illness-yes" />
                    <Label htmlFor="illness-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="illness-no" />
                    <Label htmlFor="illness-no">No</Label>
                  </div>
                </RadioGroup>
              </div>

              {showDiseaseDetails && (
                <Card className="bg-accent/50 border-accent-foreground/20">
                  <CardContent className="p-4 space-y-4">
                    <h4 className="font-semibold text-accent-foreground">Additional Details:</h4>
                    
                    <div className="space-y-2">
                      <Label>What disease(s) did you suffer from?</Label>
                      <Input
                        placeholder="Enter disease name(s)"
                        value={healthData.diseaseDetails?.diseaseName || ""}
                        onChange={(e) => setHealthData(prev => ({
                          ...prev,
                          diseaseDetails: {
                            ...prev.diseaseDetails!,
                            diseaseName: e.target.value
                          }
                        }))}
                        className="bg-background"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Where did you fall sick?</Label>
                      <RadioGroup 
                        value={healthData.diseaseDetails?.location || ""} 
                        onValueChange={(value) => setHealthData(prev => ({
                          ...prev,
                          diseaseDetails: {
                            ...prev.diseaseDetails!,
                            location: value
                          }
                        }))}
                        className="flex gap-6"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="kerala" id="location-kerala" />
                          <Label htmlFor="location-kerala">In Kerala</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="outside" id="location-outside" />
                          <Label htmlFor="location-outside">Outside of Kerala</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <Label>Where did you get treated?</Label>
                      <Input
                        placeholder="Hospital/clinic name, city, and state"
                        value={healthData.diseaseDetails?.treatment || ""}
                        onChange={(e) => setHealthData(prev => ({
                          ...prev,
                          diseaseDetails: {
                            ...prev.diseaseDetails!,
                            treatment: e.target.value
                          }
                        }))}
                        className="bg-background"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>When was your last checkup?</Label>
                      <RadioGroup 
                        value={healthData.diseaseDetails?.lastCheckup || ""} 
                        onValueChange={(value) => setHealthData(prev => ({
                          ...prev,
                          diseaseDetails: {
                            ...prev.diseaseDetails!,
                            lastCheckup: value
                          }
                        }))}
                        className="flex gap-6"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="1-2-months" id="checkup-1-2" />
                          <Label htmlFor="checkup-1-2">Between 1-2 months</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="2-3-months" id="checkup-2-3" />
                          <Label htmlFor="checkup-2-3">Between 2-3 months</Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Question 2: Chronic Diseases */}
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  2. Are you suffering from any chronic diseases?
                </h3>
                <RadioGroup 
                  value={healthData.chronicDiseases} 
                  onValueChange={handleChronicDiseasesChange}
                  className="flex gap-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="chronic-yes" />
                    <Label htmlFor="chronic-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="chronic-no" />
                    <Label htmlFor="chronic-no">No</Label>
                  </div>
                </RadioGroup>
              </div>

              {showChronicDetails && (
                <Card className="bg-accent/50 border-accent-foreground/20">
                  <CardContent className="p-4 space-y-4">
                    <h4 className="font-semibold text-accent-foreground">Select chronic diseases:</h4>
                    
                    <div className="space-y-3">
                      {["Asthma", "Thyroid", "Diabetes"].map((disease) => (
                        <div key={disease} className="flex items-center space-x-2">
                          <Checkbox
                            id={disease.toLowerCase()}
                            checked={healthData.chronicDiseaseDetails?.type?.includes(disease) || false}
                            onCheckedChange={(checked) => handleChronicDiseaseSelection(disease, checked as boolean)}
                          />
                          <Label htmlFor={disease.toLowerCase()}>{disease}</Label>
                        </div>
                      ))}
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="other-chronic"
                          checked={healthData.chronicDiseaseDetails?.type?.includes("Other") || false}
                          onCheckedChange={(checked) => handleChronicDiseaseSelection("Other", checked as boolean)}
                        />
                        <Label htmlFor="other-chronic">Other</Label>
                      </div>
                      
                      {healthData.chronicDiseaseDetails?.type?.includes("Other") && (
                        <Textarea
                          placeholder="Please describe the chronic disease"
                          value={healthData.chronicDiseaseDetails?.otherDisease || ""}
                          onChange={(e) => setHealthData(prev => ({
                            ...prev,
                            chronicDiseaseDetails: {
                              ...prev.chronicDiseaseDetails!,
                              otherDisease: e.target.value
                            }
                          }))}
                          className="bg-background"
                        />
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Question 3: COVID Vaccination */}
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  3. Are you vaccinated for COVID-19?
                </h3>
                <RadioGroup 
                  value={healthData.covidVaccination} 
                  onValueChange={handleCovidVaccinationChange}
                  className="flex gap-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="covid-yes" />
                    <Label htmlFor="covid-yes">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="covid-no" />
                    <Label htmlFor="covid-no">No</Label>
                  </div>
                </RadioGroup>
              </div>

              {showVaccinationUpload && (
                <Card className="bg-accent/50 border-accent-foreground/20">
                  <CardContent className="p-4 space-y-4">
                    <h4 className="font-semibold text-accent-foreground">Upload Vaccination Certificate:</h4>
                    
                    <div className="flex items-center justify-center w-full">
                      <label htmlFor="vaccination-certificate" className="flex flex-col items-center justify-center w-full h-32 border-2 border-border border-dashed rounded-lg cursor-pointer bg-muted hover:bg-muted/80">
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Upload className="w-8 h-8 mb-2 text-muted-foreground" />
                          <p className="text-sm text-muted-foreground">
                            <span className="font-semibold">Click to upload</span> vaccination certificate (JPG format)
                          </p>
                        </div>
                        <input 
                          id="vaccination-certificate" 
                          type="file" 
                          accept=".jpg,.jpeg" 
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              setHealthData(prev => ({
                                ...prev,
                                vaccinationCertificate: file
                              }));
                            }
                          }}
                        />
                      </label>
                    </div>

                    {healthData.vaccinationCertificate && (
                      <div className="flex items-center gap-2 text-health-success">
                        <CheckCircle className="w-5 h-5" />
                        <span className="text-sm">Certificate uploaded: {healthData.vaccinationCertificate.name}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Submit Button */}
            <div className="pt-8 text-center">
              <Button 
                className="px-12 py-6 text-lg bg-gradient-health hover:scale-105 transition-transform duration-300 shadow-glow"
                onClick={handleSubmit}
              >
                Complete Health Record & Continue
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Back Button */}
        <div className="text-center mt-6">
          <Button 
            variant="ghost" 
            className="text-primary-foreground hover:text-secondary"
            onClick={() => navigate('/register')}
          >
            ← Back to Registration
          </Button>
        </div>
      </div>
    </div>
  );
};

export default HealthRecordForm;