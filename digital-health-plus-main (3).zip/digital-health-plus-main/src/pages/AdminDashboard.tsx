import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import SpeakButton from "@/components/SpeakButton";
import { 
  Heart, 
  Users, 
  UserCog, 
  Stethoscope, 
  Building2, 
  CheckCircle, 
  XCircle, 
  Eye,
  Search,
  LogOut
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";

interface Patient {
  id: string;
  name: string;
  age: number;
  mobile: string;
  email?: string;
  state: string;
  yearMovedToKerala: number;
  bloodGroup: string;
  height: string;
  weight: string;
  aadhar: string;
  healthRecords: any[];
  appointments: number;
}

interface Doctor {
  id: string;
  name: string;
  specialization: string;
  hospital: string;
  experience: number;
  consultations: number;
  rating: number;
}

interface Hospital {
  id: string;
  name: string;
  city: string;
  address: string;
  phoneNumber: string;
  departments: string[];
  isApproved: boolean;
  region: string;
}

const AdminDashboard = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Load mock data
    const mockPatients: Patient[] = [
      {
        id: "TAHSU56775556",
        name: "Rahul Kumar",
        age: 28,
        mobile: "9876543210",
        email: "rahul@example.com",
        state: "Uttar Pradesh",
        yearMovedToKerala: 2020,
        bloodGroup: "B+",
        height: "175 cm",
        weight: "70 kg",
        aadhar: "1234-5678-9012",
        healthRecords: [],
        appointments: 3
      },
      {
        id: "KERLA98765432",
        name: "Priya Singh",
        age: 32,
        mobile: "8765432109",
        email: "priya@example.com",
        state: "Bihar",
        yearMovedToKerala: 2018,
        bloodGroup: "A+",
        height: "162 cm",
        weight: "58 kg",
        aadhar: "2345-6789-0123",
        healthRecords: [],
        appointments: 5
      }
    ];

    const mockDoctors: Doctor[] = [
      {
        id: "A42P0910",
        name: "Dr. Sreenivas Kumar",
        specialization: "General Medicine",
        hospital: "Kozhikode Medical College",
        experience: 15,
        consultations: 1200,
        rating: 4.8
      },
      {
        id: "B78Q1234",
        name: "Dr. Maya Nair",
        specialization: "Cardiology",
        hospital: "Thiruvananthapuram General Hospital",
        experience: 12,
        consultations: 850,
        rating: 4.9
      }
    ];

    const mockHospitals: Hospital[] = [
      {
        id: "H001",
        name: "Kozhikode Medical College",
        city: "Kozhikode",
        address: "Kozhikode Medical College Road, Kozhikode",
        phoneNumber: "0495-2359126",
        departments: ["General Medicine", "Surgery", "Pediatrics"],
        isApproved: true,
        region: "North Kerala"
      },
      {
        id: "H002",
        name: "Kottayam District Hospital",
        city: "Kottayam",
        address: "Medical College Road, Kottayam",
        phoneNumber: "0481-2563892",
        departments: ["Emergency", "Orthopedics"],
        isApproved: false,
        region: "Central Kerala"
      }
    ];

    setPatients(mockPatients);
    setDoctors(mockDoctors);
    setHospitals(mockHospitals);
  }, []);

  const approveHospital = (hospitalId: string) => {
    setHospitals(prev => 
      prev.map(hospital => 
        hospital.id === hospitalId 
          ? { ...hospital, isApproved: true }
          : hospital
      )
    );
    toast({
      title: "Hospital Approved",
      description: "Hospital has been successfully approved."
    });
  };

  const rejectHospital = (hospitalId: string) => {
    setHospitals(prev => 
      prev.map(hospital => 
        hospital.id === hospitalId 
          ? { ...hospital, isApproved: false }
          : hospital
      )
    );
    toast({
      title: "Hospital Rejected",
      description: "Hospital approval has been rejected.",
      variant: "destructive"
    });
  };

  const handleLogout = () => {
    navigate('/');
  };

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredDoctors = doctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredHospitals = hospitals.filter(hospital =>
    hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    hospital.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-kerala">
      {/* Header */}
      <div className="bg-card/95 backdrop-blur-sm border-b border-card-border shadow-medium">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
                <Heart className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-primary">Health+ Admin</h1>
                <Badge variant="secondary" className="text-xs">
                  Administrator Dashboard
                </Badge>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={handleLogout}
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card/95 backdrop-blur-sm border-card-border">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{patients.length}</p>
                  <p className="text-sm text-muted-foreground">Total Patients</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/95 backdrop-blur-sm border-card-border">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <Stethoscope className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{doctors.length}</p>
                  <p className="text-sm text-muted-foreground">Registered Doctors</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/95 backdrop-blur-sm border-card-border">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{hospitals.length}</p>
                  <p className="text-sm text-muted-foreground">Total Hospitals</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/95 backdrop-blur-sm border-card-border">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-destructive" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">
                    {hospitals.filter(h => !h.isApproved).length}
                  </p>
                  <p className="text-sm text-muted-foreground">Pending Approvals</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search patients, doctors, or hospitals..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-background border-input"
            />
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="patients" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="patients">Patients</TabsTrigger>
            <TabsTrigger value="doctors">Doctors</TabsTrigger>
            <TabsTrigger value="hospitals">Hospitals</TabsTrigger>
            <TabsTrigger value="approvals">Approvals</TabsTrigger>
          </TabsList>

          <TabsContent value="patients">
            <Card className="bg-card/95 backdrop-blur-sm border-card-border">
              <CardHeader>
                <CardTitle>Patient Management</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Patient ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Age</TableHead>
                      <TableHead>Mobile</TableHead>
                      <TableHead>State</TableHead>
                      <TableHead>Appointments</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPatients.map((patient) => (
                      <TableRow key={patient.id}>
                        <TableCell className="font-mono">{patient.id}</TableCell>
                        <TableCell>{patient.name}</TableCell>
                        <TableCell>{patient.age}</TableCell>
                        <TableCell>{patient.mobile}</TableCell>
                        <TableCell>{patient.state}</TableCell>
                        <TableCell>{patient.appointments}</TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedPatient(patient)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="doctors">
            <Card className="bg-card/95 backdrop-blur-sm border-card-border">
              <CardHeader>
                <CardTitle>Doctor Management</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Doctor ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Specialization</TableHead>
                      <TableHead>Hospital</TableHead>
                      <TableHead>Experience</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDoctors.map((doctor) => (
                      <TableRow key={doctor.id}>
                        <TableCell className="font-mono">{doctor.id}</TableCell>
                        <TableCell>{doctor.name}</TableCell>
                        <TableCell>{doctor.specialization}</TableCell>
                        <TableCell>{doctor.hospital}</TableCell>
                        <TableCell>{doctor.experience} years</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{doctor.rating}/5</Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedDoctor(doctor)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="hospitals">
            <Card className="bg-card/95 backdrop-blur-sm border-card-border">
              <CardHeader>
                <CardTitle>Hospital Management</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Hospital Name</TableHead>
                      <TableHead>City</TableHead>
                      <TableHead>Region</TableHead>
                      <TableHead>Departments</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredHospitals.map((hospital) => (
                      <TableRow key={hospital.id}>
                        <TableCell>{hospital.name}</TableCell>
                        <TableCell>{hospital.city}</TableCell>
                        <TableCell>{hospital.region}</TableCell>
                        <TableCell>{hospital.departments.length} depts</TableCell>
                        <TableCell>
                          <Badge variant={hospital.isApproved ? "default" : "destructive"}>
                            {hospital.isApproved ? "Approved" : "Pending"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {!hospital.isApproved && (
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => approveHospital(hospital.id)}
                              >
                                <CheckCircle className="w-4 h-4 mr-2" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => rejectHospital(hospital.id)}
                              >
                                <XCircle className="w-4 h-4 mr-2" />
                                Reject
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="approvals">
            <Card className="bg-card/95 backdrop-blur-sm border-card-border">
              <CardHeader>
                <CardTitle>Pending Hospital Approvals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {hospitals.filter(h => !h.isApproved).map((hospital) => (
                    <div key={hospital.id} className="border border-border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold">{hospital.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {hospital.city} • {hospital.region}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Phone: {hospital.phoneNumber}
                          </p>
                          <div className="flex gap-2 mt-2">
                            {hospital.departments.map((dept, index) => (
                              <Badge key={index} variant="outline">{dept}</Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => approveHospital(hospital.id)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            onClick={() => rejectHospital(hospital.id)}
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {hospitals.filter(h => !h.isApproved).length === 0 && (
                    <p className="text-center text-muted-foreground py-8">
                      No pending hospital approvals
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Patient Details Modal */}
      {selectedPatient && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-6 z-50">
          <Card className="w-full max-w-2xl bg-card border-card-border">
            <CardHeader>
              <CardTitle>Patient Details - {selectedPatient.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Patient ID</Label>
                  <p className="font-mono">{selectedPatient.id}</p>
                </div>
                <div>
                  <Label>Age</Label>
                  <p>{selectedPatient.age} years</p>
                </div>
                <div>
                  <Label>Mobile</Label>
                  <p>{selectedPatient.mobile}</p>
                </div>
                <div>
                  <Label>Email</Label>
                  <p>{selectedPatient.email || "Not provided"}</p>
                </div>
                <div>
                  <Label>Blood Group</Label>
                  <p>{selectedPatient.bloodGroup}</p>
                </div>
                <div>
                  <Label>State</Label>
                  <p>{selectedPatient.state}</p>
                </div>
                <div>
                  <Label>Height</Label>
                  <p>{selectedPatient.height}</p>
                </div>
                <div>
                  <Label>Weight</Label>
                  <p>{selectedPatient.weight}</p>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setSelectedPatient(null)}>
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Doctor Details Modal */}
      {selectedDoctor && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-6 z-50">
          <Card className="w-full max-w-2xl bg-card border-card-border">
            <CardHeader>
              <CardTitle>Doctor Details - {selectedDoctor.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Doctor ID</Label>
                  <p className="font-mono">{selectedDoctor.id}</p>
                </div>
                <div>
                  <Label>Specialization</Label>
                  <p>{selectedDoctor.specialization}</p>
                </div>
                <div>
                  <Label>Hospital</Label>
                  <p>{selectedDoctor.hospital}</p>
                </div>
                <div>
                  <Label>Experience</Label>
                  <p>{selectedDoctor.experience} years</p>
                </div>
                <div>
                  <Label>Total Consultations</Label>
                  <p>{selectedDoctor.consultations}</p>
                </div>
                <div>
                  <Label>Rating</Label>
                  <p>{selectedDoctor.rating}/5.0</p>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setSelectedDoctor(null)}>
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;